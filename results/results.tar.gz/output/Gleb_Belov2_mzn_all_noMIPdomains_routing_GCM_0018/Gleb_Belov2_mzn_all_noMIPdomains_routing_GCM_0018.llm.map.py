import json
import math
import sys


# These singleton domains are fixed in the original self-contained model.
FIXED_COORDINATES = {
    "nXNd__1_1_X": 245,
    "nXNd__1_1_Y": 62,
    "nXNd__1_1_Z": 122,
    "nXNd__1_10_X": 245,
    "nXNd__1_10_Y": 102,
    "nXNd__1_10_Z": 100,
}

# These are all original independent array variables. Their names,
# dimensions, index domains, and meanings are unchanged in the model.
INDEPENDENT_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)

# The coordinate names come from the original self-contained declarations.
FREE_COORDINATES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(2, 10)
    for axis in ("X", "Y", "Z")
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the solver's default "
            "DZN solution.".format(name)
        )
    return variables[name]


def require_integer(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("{} must be an integer-valued number.".format(name))
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("{} must be a finite integer.".format(name))
    return int(value)


def index_cardinality(encoded, name):
    if not isinstance(encoded, dict):
        raise ValueError("Invalid index set for " + name)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid index range for " + name)
        lower = require_integer(bounds[0], name + ".lower")
        upper = require_integer(bounds[1], name + ".upper")
        return max(0, upper - lower + 1)
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid index set elements for " + name)
        return len(elements)
    raise ValueError("Invalid index set encoding for " + name)


def copy_array(variables, name):
    value = require_variable(variables, name)
    if not isinstance(value, dict):
        raise ValueError("variables.{} must use MiniZinc array encoding.".format(name))
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables.{} requires array and index_sets fields.".format(name)
        )
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid MiniZinc array encoding for " + name)

    cardinality = 1
    for dimension, index_set in enumerate(index_sets):
        cardinality *= index_cardinality(
            index_set, "{}.index_sets[{}]".format(name, dimension)
        )
    if cardinality != len(elements):
        raise ValueError("Array size and index sets disagree for " + name)

    return {
        "array": [
            require_integer(element, "{}.array[{}]".format(name, position))
            for position, element in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object.")
    variables = data["variables"]
    result = {}

    for name, fixed_value in FIXED_COORDINATES.items():
        if name in variables and variables[name] is not None:
            result[name] = require_integer(variables[name], "variables." + name)
        else:
            result[name] = fixed_value

    for name in FREE_COORDINATES:
        result[name] = require_integer(
            require_variable(variables, name), "variables." + name
        )

    for name in INDEPENDENT_ARRAYS:
        result[name] = copy_array(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in data and data["objective"] is not None:
        result["obj"] = require_integer(data["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; the unchanged objective "
            "value is required from the reformulated solution."
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(data, "input")
    mapped = map_solution(data)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)