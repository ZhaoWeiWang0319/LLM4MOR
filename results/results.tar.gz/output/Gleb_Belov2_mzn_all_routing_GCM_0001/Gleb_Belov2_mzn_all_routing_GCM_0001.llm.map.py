import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + ": required from the default DZN solution."
        )
    return variables[name]


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(data, "input")

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = data["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 348,
        "nXNd__1_1_Y": 142,
        "nXNd__1_1_Z": 20,
        "nXNd__1_10_X": 302,
        "nXNd__1_10_Y": 60,
        "nXNd__1_10_Z": 88,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = required(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        restored[name] = required(variables, name)

    output = {"variables": restored}
    check_finite(output, "output")
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(output, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()