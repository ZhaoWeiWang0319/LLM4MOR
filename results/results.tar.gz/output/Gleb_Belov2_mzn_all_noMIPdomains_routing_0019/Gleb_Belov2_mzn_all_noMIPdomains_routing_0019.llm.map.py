import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 245,
    "nXNd__1_1_Y": 86,
    "nXNd__1_1_Z": 100,
    "nXNd__1_10_X": 245,
    "nXNd__1_10_Y": 62,
    "nXNd__1_10_Z": 58,
}

NONFIXED_COORDINATES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(2, 10)
    for axis in ("X", "Y", "Z")
)

ORIGINAL_ARRAY_VARIABLES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the reformulated "
            "model's default DZN solution.".format(name)
        )
    return variables[name]


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in document:
        raise ValueError("Missing input field: variables.")
    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("The input field variables must be an object.")

    restored = {}

    for name, fixed_value in FIXED_COORDINATES.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for name in NONFIXED_COORDINATES:
        restored[name] = required_value(variables, name)

    for name in ORIGINAL_ARRAY_VARIABLES:
        value = required_value(variables, name)
        if not isinstance(value, dict):
            raise ValueError(
                "variables.{} must use the MiniZinc array encoding.".format(name)
            )
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables.{} requires both array and index_sets.".format(name)
            )
        if not isinstance(value["array"], list):
            raise ValueError("variables.{}.array must be a list.".format(name))
        if not isinstance(value["index_sets"], list):
            raise ValueError(
                "variables.{}.index_sets must be a list.".format(name)
            )
        restored[name] = value

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in document and document["objective"] is not None:
        value = document["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("objective must be a finite integer-valued number.")
        if isinstance(value, float) and (
            not math.isfinite(value) or not value.is_integer()
        ):
            raise ValueError("objective must be a finite integer-valued number.")
        restored["obj"] = int(value)
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required "
            "to restore the original independent variable obj."
        )

    result = {"variables": restored}
    check_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)