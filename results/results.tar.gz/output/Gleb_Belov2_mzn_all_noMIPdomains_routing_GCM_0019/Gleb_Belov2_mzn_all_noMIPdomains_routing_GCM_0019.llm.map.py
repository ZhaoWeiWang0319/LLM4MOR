import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 245,
    "nXNd__1_1_Y": 86,
    "nXNd__1_1_Z": 100,
    "nXNd__1_10_X": 245,
    "nXNd__1_10_Y": 62,
    "nXNd__1_10_Z": 58,
}

COORDINATE_NAMES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the reformulated "
            "model's default DZN solution".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing input field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Input field variables must be a JSON object")

    result = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            result[name] = variables[name]
        elif name in FIXED_COORDINATES:
            result[name] = FIXED_COORDINATES[name]
        else:
            result[name] = require_variable(variables, name)

    for name in ARRAY_NAMES:
        result[name] = require_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    else:
        if "objective" not in payload or payload["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; require obj from "
                "the default DZN solution or the same solution's objective"
            )
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number")
        result["obj"] = int(objective)

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    mapped = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)