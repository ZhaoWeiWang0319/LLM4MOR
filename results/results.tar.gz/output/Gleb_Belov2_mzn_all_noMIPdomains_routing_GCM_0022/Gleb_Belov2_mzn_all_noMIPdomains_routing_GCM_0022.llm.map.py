import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 315,
    "nXNd__1_1_Y": 54,
    "nXNd__1_1_Z": 73,
    "nXNd__1_10_X": 335,
    "nXNd__1_10_Y": 53,
    "nXNd__1_10_Z": 8,
}

COORDINATE_NAMES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

OTHER_INDEPENDENT_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
    "obj",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite JSON number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from the reformulated "
            "model's default DZN solution output".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    restored = {}

    for name in COORDINATE_NAMES:
        if name in FIXED_COORDINATES:
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            else:
                restored[name] = FIXED_COORDINATES[name]
        else:
            restored[name] = require_variable(variables, name)

    for name in OTHER_INDEPENDENT_NAMES:
        restored[name] = require_variable(variables, name)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")
    serialized = json.dumps(result, allow_nan=False, separators=(",", ":"))

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        destination.write(serialized)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)