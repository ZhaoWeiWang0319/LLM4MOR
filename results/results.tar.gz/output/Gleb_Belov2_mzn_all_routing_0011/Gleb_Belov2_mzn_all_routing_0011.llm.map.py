import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from the reformulated model's "
            "default DZN solution.".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload:
        raise ValueError("Missing variables: required solution field.")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object.")

    fixed_endpoints = {
        "nXNd__1_1_X": 79,
        "nXNd__1_1_Y": 41,
        "nXNd__1_1_Z": 5,
        "nXNd__1_10_X": 125,
        "nXNd__1_10_Y": 60,
        "nXNd__1_10_Z": 163,
    }

    result = {}
    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            if name in variables and variables[name] is not None:
                result[name] = variables[name]
            elif name in fixed_endpoints:
                result[name] = fixed_endpoints[name]
            else:
                result[name] = required_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        result[name] = required_variable(variables, name)

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload, "input")
    mapped = map_solution(payload)
    check_finite(mapped, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)