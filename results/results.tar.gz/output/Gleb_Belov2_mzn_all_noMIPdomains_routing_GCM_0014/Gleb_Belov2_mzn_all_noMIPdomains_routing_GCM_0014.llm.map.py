import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 245,
    "nXNd__1_1_Y": 43,
    "nXNd__1_1_Z": 122,
    "nXNd__1_10_X": 212,
    "nXNd__1_10_Y": 52,
    "nXNd__1_10_Z": 100,
}

ARRAY_DOMAINS = {
    "nXLeg1": [list(range(1, 11)), list(range(1, 4))],
    "nXLeg2": [list(range(1, 11)), list(range(1, 4))],
    "nLLeg": [list(range(1, 11)), list(range(1, 4))],
    "nDirLeg": [list(range(1, 11))],
    "fExistLeg": [list(range(1, 11))],
    "fLastLeg": [list(range(1, 11))],
}


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def integer_value(value, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(field + " must be an integer")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError(field + " must be a finite integer")
    return int(value)


def decode_index_set(value, field):
    if not isinstance(value, dict):
        raise ValueError(field + " must use the MiniZinc set encoding")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two bounds")
        lower = integer_value(bounds[0], field + ".range[0]")
        upper = integer_value(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(field + ".set must be a list")
        elements = [integer_value(item, field + ".set") for item in elements]
        if len(elements) != len(set(elements)):
            raise ValueError(field + " contains duplicate indices")
        return sorted(elements)
    raise ValueError(field + " must contain exactly 'range' or 'set'")


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name +
            "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def copy_array(variables, name, expected_domains):
    value = required_variable(variables, name)
    if not isinstance(value, dict):
        raise ValueError("variables." + name + " must use MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables." + name + " requires 'array' and 'index_sets'"
        )

    encoded_domains = value["index_sets"]
    if not isinstance(encoded_domains, list):
        raise ValueError("variables." + name + ".index_sets must be a list")

    domains = [
        decode_index_set(domain, "variables." + name + ".index_sets")
        for domain in encoded_domains
    ]
    if domains != expected_domains:
        raise ValueError("Incorrect index domains for variables." + name)

    elements = value["array"]
    expected_length = math.prod(len(domain) for domain in expected_domains)
    if not isinstance(elements, list) or len(elements) != expected_length:
        raise ValueError("Incorrect element count for variables." + name)

    return {
        "array": [
            integer_value(element, "variables." + name + ".array")
            for element in elements
        ],
        "index_sets": encoded_domains,
    }


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = data["variables"]
    restored = {}

    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            if name in variables and variables[name] is not None:
                restored[name] = integer_value(
                    variables[name], "variables." + name
                )
            elif name in FIXED_COORDINATES:
                restored[name] = FIXED_COORDINATES[name]
            else:
                restored[name] = integer_value(
                    required_variable(variables, name), "variables." + name
                )

    for name, domains in ARRAY_DOMAINS.items():
        restored[name] = copy_array(variables, name, domains)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = integer_value(variables["obj"], "variables.obj")
    else:
        if "objective" not in data or data["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; one is required "
                "from the reformulated solution"
            )
        restored["obj"] = integer_value(data["objective"], "objective")

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    result = map_solution(data)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()