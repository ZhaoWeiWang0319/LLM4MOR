import json
import sys
required = ['fExistLeg', 'fLastLeg', 'nDirLeg', 'nLLeg', 'nXLeg1', 'nXLeg2', 'nXNd__1_10_X', 'nXNd__1_10_Y', 'nXNd__1_10_Z', 'nXNd__1_1_X', 'nXNd__1_1_Y', 'nXNd__1_1_Z', 'nXNd__1_2_X', 'nXNd__1_2_Y', 'nXNd__1_2_Z', 'nXNd__1_3_X', 'nXNd__1_3_Y', 'nXNd__1_3_Z', 'nXNd__1_4_X', 'nXNd__1_4_Y', 'nXNd__1_4_Z', 'nXNd__1_5_X', 'nXNd__1_5_Y', 'nXNd__1_5_Z', 'nXNd__1_6_X', 'nXNd__1_6_Y', 'nXNd__1_6_Z', 'nXNd__1_7_X', 'nXNd__1_7_Y', 'nXNd__1_7_Z', 'nXNd__1_8_X', 'nXNd__1_8_Y', 'nXNd__1_8_Z', 'nXNd__1_9_X', 'nXNd__1_9_Y', 'nXNd__1_9_Z', 'obj']
with open(sys.argv[1], encoding='utf-8') as stream:
    solution = json.load(stream)
with open(sys.argv[2], 'w', encoding='utf-8') as stream:
    json.dump({'variables': {name: solution['variables'][name] for name in required}}, stream, allow_nan=False)
