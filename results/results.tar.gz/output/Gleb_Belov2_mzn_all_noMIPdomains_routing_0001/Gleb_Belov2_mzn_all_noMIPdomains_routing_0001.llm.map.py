import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 348,
    "nXNd__1_1_Y": 142,
    "nXNd__1_1_Z": 20,
    "nXNd__1_10_X": 302,
    "nXNd__1_10_Y": 60,
    "nXNd__1_10_Z": 88,
}

COORDINATE_NAMES = tuple(
    f"nXNd__1_{node}_{axis}"
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError(f"Nonfinite JSON number: {value}")


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"Nonfinite number at {path}")
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, f"{path}.{key}")
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, f"{path}[{position}]")


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{path} must be an integer")
    return value


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError(f"{path} must use the MiniZinc set encoding")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(f"{path}.range must contain two integers")
        lower = require_integer(bounds[0], f"{path}.range[0]")
        upper = require_integer(bounds[1], f"{path}.range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        members = value["set"]
        if not isinstance(members, list):
            raise ValueError(f"{path}.set must be an array")
        for position, member in enumerate(members):
            require_integer(member, f"{path}.set[{position}]")
        if len(set(members)) != len(members):
            raise ValueError(f"{path} contains duplicate indices")
        return sorted(members)
    raise ValueError(f"{path} has an invalid index-set encoding")


def require_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            f"Missing variables.{name}; required from the default DZN "
            "solution of the reformulated model"
        )
    return variables[name]


def validate_array(name, value):
    if not isinstance(value, dict):
        raise ValueError(f"variables.{name} must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            f"variables.{name} requires both array and index_sets"
        )
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError(f"Invalid array encoding for variables.{name}")

    expected_dimensions = 2 if name in ("nXLeg1", "nXLeg2", "nLLeg") else 1
    if len(index_sets) != expected_dimensions:
        raise ValueError(f"Wrong number of dimensions for variables.{name}")

    expected_domains = [list(range(1, 11))]
    if expected_dimensions == 2:
        expected_domains.append(list(range(1, 4)))

    size = 1
    for position, (encoded, expected) in enumerate(
        zip(index_sets, expected_domains)
    ):
        domain = decode_index_set(
            encoded, f"variables.{name}.index_sets[{position}]"
        )
        if domain != expected:
            raise ValueError(
                f"Incorrect original index domain for variables.{name}, "
                f"dimension {position + 1}"
            )
        size *= len(domain)

    if len(elements) != size:
        raise ValueError(f"Incorrect element count for variables.{name}")
    for position, element in enumerate(elements):
        require_integer(element, f"variables.{name}.array[{position}]")
    return value


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = data["variables"]
    result = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            result[name] = require_integer(variables[name], f"variables.{name}")
        elif name in FIXED_COORDINATES:
            result[name] = FIXED_COORDINATES[name]
        else:
            result[name] = require_integer(
                require_value(variables, name), f"variables.{name}"
            )

    for name in ARRAY_NAMES:
        result[name] = validate_array(name, require_value(variables, name))

    result["obj"] = require_integer(
        require_value(variables, "obj"), "variables.obj"
    )
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(data, "input")
    result = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(f"Mapping error: {error}", file=sys.stderr)
        sys.exit(1)