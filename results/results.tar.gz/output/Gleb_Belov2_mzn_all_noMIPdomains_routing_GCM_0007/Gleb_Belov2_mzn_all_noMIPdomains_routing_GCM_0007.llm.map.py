import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def integer(value, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(field + " must be an integer")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError(field + " must be a finite integer")
    return int(value)


def decode_index(encoded, field):
    if not isinstance(encoded, dict):
        raise ValueError(field + " must use the MiniZinc set encoding")
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two bounds")
        lower = integer(bounds[0], field + ".range[0]")
        upper = integer(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))
    if set(encoded) == {"set"}:
        members = encoded["set"]
        if not isinstance(members, list):
            raise ValueError(field + ".set must be an array")
        values = [integer(v, field + ".set") for v in members]
        if values != sorted(set(values)):
            raise ValueError(
                field + ".set must be sorted and contain no duplicates"
            )
        return values
    raise ValueError(field + " has an invalid index-set encoding")


def copy_array(value, field, expected_domains):
    if not isinstance(value, dict):
        raise ValueError(field + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(field + " requires array and index_sets")
    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(domains, list):
        raise ValueError(field + " has malformed array encoding")
    if len(domains) != len(expected_domains):
        raise ValueError(field + " has an incorrect number of dimensions")
    count = 1
    for dimension, (domain, expected) in enumerate(
        zip(domains, expected_domains)
    ):
        actual = decode_index(
            domain, field + ".index_sets[" + str(dimension) + "]"
        )
        if actual != expected:
            raise ValueError(field + " has an incorrect index domain")
        count *= len(actual)
    if len(elements) != count:
        raise ValueError(field + " has an incorrect element count")
    return {
        "array": [
            integer(element, field + ".array[" + str(i) + "]")
            for i, element in enumerate(elements)
        ],
        "index_sets": domains,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(
        payload["variables"], dict
    ):
        raise ValueError("Missing or invalid input field: variables")

    variables = payload["variables"]
    restored = {}

    # Fixed singleton domains from the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 153,
        "nXNd__1_1_Y": 51,
        "nXNd__1_1_Z": 13,
        "nXNd__1_10_X": 168,
        "nXNd__1_10_Y": 52,
        "nXNd__1_10_Z": 76,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = integer(
                    variables[name], "variables." + name
                )
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                raise ValueError(
                    "Missing required field variables." + name
                    + "; source must be the model's default DZN solution"
                )

    # These domains are unchanged from the original self-contained model.
    leg_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))
    array_domains = {
        "nXLeg1": [leg_domain, coordinate_domain],
        "nXLeg2": [leg_domain, coordinate_domain],
        "nLLeg": [leg_domain, coordinate_domain],
        "nDirLeg": [leg_domain],
        "fExistLeg": [leg_domain],
        "fLastLeg": [leg_domain],
    }

    for name, domains in array_domains.items():
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables." + name
                + "; source must be the model's default DZN solution"
            )
        restored[name] = copy_array(
            variables[name], "variables." + name, domains
        )

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        restored["obj"] = integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing required field variables.obj or objective; "
            "the original obj is the unchanged minimization objective"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    main()