import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 335,
    "nXNd__1_1_Y": 43,
    "nXNd__1_1_Z": 8,
    "nXNd__1_10_X": 315,
    "nXNd__1_10_Y": 54,
    "nXNd__1_10_Z": 93,
}

COORDINATE_VARIABLES = (
    "nXNd__1_1_X", "nXNd__1_1_Y", "nXNd__1_1_Z",
    "nXNd__1_2_X", "nXNd__1_2_Y", "nXNd__1_2_Z",
    "nXNd__1_3_X", "nXNd__1_3_Y", "nXNd__1_3_Z",
    "nXNd__1_4_X", "nXNd__1_4_Y", "nXNd__1_4_Z",
    "nXNd__1_5_X", "nXNd__1_5_Y", "nXNd__1_5_Z",
    "nXNd__1_6_X", "nXNd__1_6_Y", "nXNd__1_6_Z",
    "nXNd__1_7_X", "nXNd__1_7_Y", "nXNd__1_7_Z",
    "nXNd__1_8_X", "nXNd__1_8_Y", "nXNd__1_8_Z",
    "nXNd__1_9_X", "nXNd__1_9_Y", "nXNd__1_9_Z",
    "nXNd__1_10_X", "nXNd__1_10_Y", "nXNd__1_10_Z",
)

ARRAY_VARIABLES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from default DZN solver output".format(name)
        )
    return variables[name]


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = document["variables"]
    restored = {}

    for name in COORDINATE_VARIABLES:
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in FIXED_COORDINATES:
            restored[name] = FIXED_COORDINATES[name]
        else:
            restored[name] = required_value(variables, name)

    for name in ARRAY_VARIABLES:
        restored[name] = required_value(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in document and document["objective"] is not None:
        value = document["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(value, float) and (
            not math.isfinite(value) or not value.is_integer()
        ):
            raise ValueError("objective must be a finite integer-valued number")
        restored["obj"] = int(value)
    else:
        raise ValueError(
            "Missing variables.obj and objective: one must supply the unchanged objective value"
        )

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)