import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{}; expected from the "
            "reformulated model's default DZN solution.".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables.")

    variables = payload["variables"]
    restored = {}

    fixed_endpoints = {
        "nXNd__1_1_X": 210,
        "nXNd__1_1_Y": 83,
        "nXNd__1_1_Z": 52,
        "nXNd__1_10_X": 55,
        "nXNd__1_10_Y": 114,
        "nXNd__1_10_Z": 80,
    }
    restored.update(fixed_endpoints)

    for node in range(2, 10):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            restored[name] = require_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        restored[name] = require_variable(variables, name)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, ensure_ascii=False)
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)