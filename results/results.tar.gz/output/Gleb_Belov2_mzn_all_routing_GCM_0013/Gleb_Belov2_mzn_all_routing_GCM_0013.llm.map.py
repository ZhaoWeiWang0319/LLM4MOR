import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = data["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 210,
        "nXNd__1_1_Y": 77,
        "nXNd__1_1_Z": 52,
        "nXNd__1_10_X": 236,
        "nXNd__1_10_Y": 62,
        "nXNd__1_10_Z": 181,
    }

    for name, fixed_value in fixed_coordinates.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    required_names = [
        "nXNd__1_{}_{}".format(node, axis)
        for node in range(2, 10)
        for axis in ("X", "Y", "Z")
    ]
    required_names.extend([
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ])

    missing = [
        name for name in required_names
        if name not in variables or variables[name] is None
    ]
    if missing:
        raise ValueError(
            "Missing required fields from the solver's default DZN solution: "
            + ", ".join("variables." + name for name in missing)
        )

    for name in required_names:
        restored[name] = variables[name]

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(data, "input")
    result = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()