import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 185,
    "nXNd__1_1_Y": 53,
    "nXNd__1_1_Z": 58,
    "nXNd__1_10_X": 288,
    "nXNd__1_10_Y": 25,
    "nXNd__1_10_Z": 3,
}

RETAINED_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, child in value.items():
            check_finite(child, path + "." + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            check_finite(child, path + "[" + str(index) + "]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; source must be the reformulated model's default DZN solution."
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in payload:
        raise ValueError("Missing required field variables.")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object.")

    restored = {}

    for name, fixed_value in FIXED_ENDPOINTS.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for node in range(2, 10):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + coordinate
            restored[name] = require_variable(variables, name)

    for name in RETAINED_ARRAYS:
        restored[name] = require_variable(variables, name)

    restored["obj"] = require_variable(variables, "obj")

    result = {"variables": restored}
    check_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)