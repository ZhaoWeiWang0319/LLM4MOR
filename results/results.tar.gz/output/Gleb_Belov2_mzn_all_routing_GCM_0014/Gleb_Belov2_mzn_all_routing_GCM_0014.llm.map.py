import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, element in enumerate(value):
            check_finite(element, f"{path}[{position}]")
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, f"{path}.{key}")


def require_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            f"Missing variables.{name}; required from the default DZN solution."
        )
    return variables[name]


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{path} must be an integer.")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError(f"{path} must be a finite integer.")
    return int(value)


def index_size(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError(f"{path} must use MiniZinc index-set encoding.")
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(f"{path}.range must contain two bounds.")
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return max(0, upper - lower + 1)
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError(f"{path}.set must be a list.")
        return len(elements)
    raise ValueError(f"Invalid index-set encoding at {path}.")


def require_array(variables, name, dimensions):
    value = require_value(variables, name)
    if not isinstance(value, dict):
        raise ValueError(f"variables.{name} must use MiniZinc array encoding.")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            f"variables.{name} requires both array and index_sets."
        )
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError(f"Invalid array encoding for variables.{name}.")
    if len(index_sets) != dimensions:
        raise ValueError(
            f"variables.{name} must have {dimensions} index dimensions."
        )
    count = 1
    for dimension, encoded in enumerate(index_sets):
        count *= index_size(
            encoded, f"variables.{name}.index_sets[{dimension}]"
        )
    if len(elements) != count:
        raise ValueError(
            f"variables.{name} has {len(elements)} elements, "
            f"but its index sets require {count}."
        )
    for position, element in enumerate(elements):
        require_integer(element, f"variables.{name}.array[{position}]")
    return {"array": elements, "index_sets": index_sets}


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object.")
    variables = payload["variables"]
    result = {}

    # These six values are fixed by singleton domains in the original
    # self-contained model, and may be omitted from default DZN output.
    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 43,
        "nXNd__1_1_Z": 122,
        "nXNd__1_10_X": 212,
        "nXNd__1_10_Y": 52,
        "nXNd__1_10_Z": 100,
    }
    for name, fixed_value in fixed_coordinates.items():
        if name in variables and variables[name] is not None:
            result[name] = require_integer(variables[name], "variables." + name)
        else:
            result[name] = fixed_value

    # All nonfixed original coordinate variables are retained independently
    # in the reformulated model and read from its default DZN output.
    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = f"nXNd__1_{node}_{axis}"
            result[name] = require_integer(
                require_value(variables, name), "variables." + name
            )

    # Copy only original independent arrays, preserving their index encoding.
    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = require_array(variables, name, 2)
    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = require_array(variables, name, 1)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; the original obj requires "
            "the unchanged reformulated objective value."
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(f"Mapping error: {error}", file=sys.stderr)
        sys.exit(1)