import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 153,
    "nXNd__1_1_Y": 51,
    "nXNd__1_1_Z": 13,
    "nXNd__1_10_X": 168,
    "nXNd__1_10_Y": 52,
    "nXNd__1_10_Z": 76,
}

COORDINATE_NAMES = [
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
]

ARRAY_DIMENSIONS = {
    "nXLeg1": [(1, 10), (1, 3)],
    "nXLeg2": [(1, 10), (1, 3)],
    "nLLeg": [(1, 10), (1, 3)],
    "nDirLeg": [(1, 10)],
    "fExistLeg": [(1, 10)],
    "fLastLeg": [(1, 10)],
}


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("Expected an integer at " + path)
    return value


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the default DZN "
            "solution of the reformulated model".format(name)
        )
    return variables[name]


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded index set at " + path)

    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid index range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))

    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid index set at " + path)
        for index, element in enumerate(elements):
            require_integer(element, "{}.set[{}]".format(path, index))
        if len(set(elements)) != len(elements):
            raise ValueError("Duplicate index-set element at " + path)
        return sorted(elements)

    raise ValueError("Invalid index-set encoding at " + path)


def copy_array(variables, name, dimensions):
    value = require_variable(variables, name)
    path = "variables." + name

    if not isinstance(value, dict):
        raise ValueError("Expected MiniZinc array encoding at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)

    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid MiniZinc array encoding at " + path)
    if len(index_sets) != len(dimensions):
        raise ValueError("Incorrect number of dimensions at " + path)

    expected_length = 1
    for dimension, ((lower, upper), encoded) in enumerate(
        zip(dimensions, index_sets)
    ):
        actual = decode_index_set(
            encoded, "{}.index_sets[{}]".format(path, dimension)
        )
        expected = list(range(lower, upper + 1))
        if actual != expected:
            raise ValueError(
                "Incorrect original index domain at {}.index_sets[{}]".format(
                    path, dimension
                )
            )
        expected_length *= len(expected)

    if len(elements) != expected_length:
        raise ValueError("Incorrect element count at " + path)

    for index, element in enumerate(elements):
        require_integer(element, "{}.array[{}]".format(path, index))

    return {"array": elements, "index_sets": index_sets}


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = payload["variables"]
    restored = {}

    for name in COORDINATE_NAMES:
        if name in FIXED_COORDINATES:
            if name in variables and variables[name] is not None:
                restored[name] = require_integer(
                    variables[name], "variables." + name
                )
            else:
                restored[name] = FIXED_COORDINATES[name]
        else:
            restored[name] = require_integer(
                require_variable(variables, name), "variables." + name
            )

    for name, dimensions in ARRAY_DIMENSIONS.items():
        restored[name] = copy_array(variables, name, dimensions)

    restored["obj"] = require_integer(
        require_variable(variables, "obj"), "variables.obj"
    )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)