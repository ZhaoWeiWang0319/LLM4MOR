import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def require_integer(value, path):
    if type(value) is not int:
        raise ValueError("Expected an integer at " + path)
    return value


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        for index, item in enumerate(elements):
            require_integer(item, "{}.set[{}]".format(path, index))
        if elements != sorted(set(elements)):
            raise ValueError("Index set must contain distinct ascending integers at " + path)
        return elements
    raise ValueError("Invalid index-set encoding at " + path)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the model's default DZN solution".format(name)
        )
    return variables[name]


def copy_array(variables, name, expected_domains, context_indices):
    value = require_variable(variables, name)
    path = "variables." + name
    if not isinstance(value, dict) or set(value) != {"array", "index_sets"}:
        raise ValueError("Expected MiniZinc array encoding at " + path)
    elements = value["array"]
    encoded_domains = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(encoded_domains, list):
        raise ValueError("Invalid array encoding at " + path)
    domains = [
        decode_index_set(domain, "{}.index_sets[{}]".format(path, index))
        for index, domain in enumerate(encoded_domains)
    ]
    if domains != expected_domains:
        raise ValueError("Incorrect original index domains at " + path)
    count = math.prod(len(domain) for domain in domains)
    if len(elements) != count:
        raise ValueError("Incorrect element count at " + path)
    for index, item in enumerate(elements):
        require_integer(item, "{}.array[{}]".format(path, index))
    if name in context_indices:
        supplied = context_indices[name]
        if not isinstance(supplied, list):
            raise ValueError("Invalid indices." + name)
        original_domains = [
            decode_index_set(domain, "indices.{}[{}]".format(name, index))
            for index, domain in enumerate(supplied)
        ]
        if original_domains != domains:
            raise ValueError("Array domains disagree with indices." + name)
    return value


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")
    variables = payload["variables"]

    context_indices = payload["indices"] if "indices" in payload else {}
    if not isinstance(context_indices, dict):
        raise ValueError("Invalid indices object")

    # These constants and domains are embedded in the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 246,
        "nXNd__1_1_Y": 43,
        "nXNd__1_1_Z": 45,
        "nXNd__1_10_X": 211,
        "nXNd__1_10_Y": 53,
        "nXNd__1_10_Z": 5,
    }

    result = {}
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                result[name] = require_integer(variables[name], "variables." + name)
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                raise ValueError(
                    "Missing variables.{}; required from the model's default DZN solution".format(name)
                )

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))
    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = copy_array(
            variables, name, [node_domain, coordinate_domain], context_indices
        )
    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = copy_array(
            variables, name, [node_domain], context_indices
        )

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    else:
        if "objective" not in payload or payload["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; one is required to restore obj"
            )
        objective = payload["objective"]
        if type(objective) is int:
            result["obj"] = objective
        elif (
            type(objective) is float
            and math.isfinite(objective)
            and objective.is_integer()
        ):
            result["obj"] = int(objective)
        else:
            raise ValueError("objective must be a finite integer-valued number")

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)