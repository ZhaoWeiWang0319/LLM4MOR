import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + " from the reformulated model's default DZN solution"
        )
    return variables[name]


def map_solution(data):
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = data["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 176,
        "nXNd__1_1_Y": 44,
        "nXNd__1_1_Z": 27,
        "nXNd__1_10_X": 210,
        "nXNd__1_10_Y": 83,
        "nXNd__1_10_Z": 45,
    }
    result.update(fixed_coordinates)

    for node in range(2, 10):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + coordinate
            result[name] = require_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        result[name] = require_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("Field objective must be a finite integer-valued number")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("Field objective must be a finite integer-valued number")
        result["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing required field variables.obj from the default DZN solution "
            "or objective from the same reformulated solution"
        )

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(data, "input")
    mapped = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(mapped, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)