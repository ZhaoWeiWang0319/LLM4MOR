import itertools
import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def require(container, key, source):
    if key not in container or container[key] is None:
        raise ValueError("Missing required field " + source + "." + key)
    return container[key]


def integer(value, source):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected an integer at " + source)


def decode_index_set(value, source):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded index set at " + source)
    if "range" in value:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + source)
        lower = integer(bounds[0], source)
        upper = integer(bounds[1], source)
        return list(range(lower, upper + 1))
    if "set" in value:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + source)
        elements = [integer(element, source) for element in elements]
        if len(elements) != len(set(elements)):
            raise ValueError("Duplicate index at " + source)
        return sorted(elements)
    raise ValueError("Missing range or set at " + source)


def decode_integer_array(value, source):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded array at " + source)
    elements = require(value, "array", source)
    index_sets = require(value, "index_sets", source)
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + source)
    domains = [
        decode_index_set(domain, source + ".index_sets[" + str(axis) + "]")
        for axis, domain in enumerate(index_sets)
    ]
    expected = math.prod(len(domain) for domain in domains)
    if len(elements) != expected:
        raise ValueError("Array size does not match index sets at " + source)
    values = [
        integer(element, source + ".array[" + str(position) + "]")
        for position, element in enumerate(elements)
    ]
    lookup = dict(zip(itertools.product(*domains), values))
    encoded = {"array": values, "index_sets": index_sets}
    return encoded, domains, lookup


def indexed(lookup, indices, source):
    if indices not in lookup:
        raise ValueError(
            "Missing required index " + repr(indices) + " in " + source
        )
    return lookup[indices]


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    variables = require(payload, "variables", "input")
    if not isinstance(variables, dict):
        raise ValueError("input.variables must be an object")

    output = {}
    decoded = {}
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        value = require(variables, name, "variables")
        encoded, domains, lookup = decode_integer_array(
            value, "variables." + name
        )
        output[name] = encoded
        decoded[name] = (domains, lookup)

    if "obj" in variables and variables["obj"] is not None:
        output["obj"] = integer(variables["obj"], "variables.obj")
    else:
        output["obj"] = integer(
            require(payload, "objective", "input"), "input.objective"
        )

    # These fixed data are embedded in the original self-contained model.
    node_pipe = (1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
    diameters = {1: 4}
    endpoints = {
        1: (309, 54, 101),
        len(node_pipe): (153, 51, 38),
    }
    axis_names = ("X", "Y", "Z")

    lower_domains, lower = decoded["nXLeg1"]
    upper_domains, upper = decoded["nXLeg2"]
    direction_domains, directions = decoded["nDirLeg"]
    if len(lower_domains) != 2 or len(upper_domains) != 2:
        raise ValueError("nXLeg1 and nXLeg2 must have two index dimensions")
    if len(direction_domains) != 1:
        raise ValueError("nDirLeg must have one index dimension")

    for node, pipe in enumerate(node_pipe, start=1):
        radius = diameters[pipe] // 2
        for axis, axis_name in enumerate(axis_names, start=1):
            name = "nXNd__" + str(pipe) + "_" + str(node) + "_" + axis_name
            if name in variables and variables[name] is not None:
                output[name] = integer(variables[name], "variables." + name)
            elif node in endpoints:
                output[name] = endpoints[node][axis - 1]
            else:
                direction = indexed(
                    directions, (node,), "variables.nDirLeg"
                )
                if direction == axis + len(axis_names):
                    output[name] = indexed(
                        upper, (node, axis), "variables.nXLeg2"
                    ) - radius
                else:
                    output[name] = indexed(
                        lower, (node, axis), "variables.nXLeg1"
                    ) + radius

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(
            {"variables": output},
            handle,
            allow_nan=False,
            separators=(",", ":"),
        )
        handle.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)