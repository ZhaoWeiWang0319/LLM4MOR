import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 308,
    "nXNd__1_1_Y": 25,
    "nXNd__1_1_Z": 3,
    "nXNd__1_10_X": 308,
    "nXNd__1_10_Y": 47,
    "nXNd__1_10_Z": 48,
}

FREE_COORDINATES = tuple(
    f"nXNd__1_{node}_{axis}"
    for node in range(2, 10)
    for axis in ("X", "Y", "Z")
)

ARRAY_VARIABLES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError(f"Non-finite JSON number: {value}")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def require_integer(value, field):
    if isinstance(value, bool):
        raise ValueError(f"{field} must be an integer, not a Boolean")
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(f"{field} must be a finite integer")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            f"Missing variables.{name}; required from the default DZN "
            "solution of the reformulated model"
        )
    return variables[name]


def index_cardinality(encoded, field):
    if not isinstance(encoded, dict):
        raise ValueError(f"{field} must use the MiniZinc set encoding")

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(f"{field}.range must contain two integer bounds")
        lower = require_integer(bounds[0], f"{field}.range[0]")
        upper = require_integer(bounds[1], f"{field}.range[1]")
        return max(0, upper - lower + 1)

    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError(f"{field}.set must be a list")
        normalized = [
            require_integer(value, f"{field}.set[{position}]")
            for position, value in enumerate(elements)
        ]
        if len(set(normalized)) != len(normalized):
            raise ValueError(f"{field}.set contains duplicate indices")
        return len(normalized)

    raise ValueError(f"{field} must contain exactly 'range' or 'set'")


def copy_integer_array(variables, name):
    value = require_variable(variables, name)
    if not isinstance(value, dict):
        raise ValueError(f"variables.{name} must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            f"variables.{name} must contain 'array' and 'index_sets'"
        )

    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError(
            f"variables.{name}.array and index_sets must be lists"
        )

    expected_rank = 2 if name in ("nXLeg1", "nXLeg2", "nLLeg") else 1
    if len(index_sets) != expected_rank:
        raise ValueError(
            f"variables.{name} must have {expected_rank} index sets"
        )

    count = 1
    for dimension, index_set in enumerate(index_sets):
        count *= index_cardinality(
            index_set, f"variables.{name}.index_sets[{dimension}]"
        )

    if count != len(elements):
        raise ValueError(
            f"variables.{name}: element count does not match index sets"
        )

    return {
        "array": [
            require_integer(element, f"variables.{name}.array[{position}]")
            for position, element in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("The input must be a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = document["variables"]
    restored = {}

    for name, fixed_value in FIXED_COORDINATES.items():
        if name in variables and variables[name] is not None:
            restored[name] = require_integer(variables[name], f"variables.{name}")
        else:
            restored[name] = fixed_value

    for name in FREE_COORDINATES:
        restored[name] = require_integer(
            require_variable(variables, name), f"variables.{name}"
        )

    for name in ARRAY_VARIABLES:
        restored[name] = copy_integer_array(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in document and document["objective"] is not None:
        restored["obj"] = require_integer(document["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; the original obj variable "
            "requires the unchanged reformulated objective value"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(f"Mapping error: {error}", file=sys.stderr)
        sys.exit(1)