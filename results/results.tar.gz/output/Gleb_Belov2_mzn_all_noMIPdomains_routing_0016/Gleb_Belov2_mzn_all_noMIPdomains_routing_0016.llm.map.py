import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            validate_finite(item, path + "[" + str(position) + "]")


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; expected in the reformulated model's default DZN solution"
        )
    return variables[name]


def integer_value(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer for " + name)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer for " + name)
        return int(value)
    return value


def original_array(variables, name):
    value = required(variables, name)
    if not isinstance(value, dict):
        raise ValueError("Expected encoded MiniZinc array for variables." + name)
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "Missing array or index_sets in variables." + name
        )
    if not isinstance(value["array"], list):
        raise ValueError("Expected a list in variables." + name + ".array")
    if not isinstance(value["index_sets"], list):
        raise ValueError("Expected a list in variables." + name + ".index_sets")
    return {
        "array": [
            integer_value(item, "variables." + name + ".array")
            for item in value["array"]
        ],
        "index_sets": value["index_sets"],
    }


def map_solution(document):
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing required object variables")
    variables = document["variables"]
    restored = {}

    # These singleton domains are fixed in the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 210,
        "nXNd__1_1_Y": 83,
        "nXNd__1_1_Z": 52,
        "nXNd__1_10_X": 55,
        "nXNd__1_10_Y": 114,
        "nXNd__1_10_Z": 80,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = integer_value(
                    required(variables, name), "variables." + name
                )

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        restored[name] = original_array(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = integer_value(variables["obj"], "variables.obj")
    elif "objective" in document and document["objective"] is not None:
        restored["obj"] = integer_value(document["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required to restore obj"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    validate_finite(document, "input")
    result = map_solution(document)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()