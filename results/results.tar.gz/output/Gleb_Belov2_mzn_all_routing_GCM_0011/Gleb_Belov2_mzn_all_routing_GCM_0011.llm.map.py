import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 79,
    "nXNd__1_1_Y": 41,
    "nXNd__1_1_Z": 5,
    "nXNd__1_10_X": 125,
    "nXNd__1_10_Y": 60,
    "nXNd__1_10_Z": 163,
}

RETAINED_ARRAYS = {
    "nXLeg1": ((1, 10), (1, 3)),
    "nXLeg2": ((1, 10), (1, 3)),
    "nLLeg": ((1, 10), (1, 3)),
    "nDirLeg": ((1, 10),),
    "fExistLeg": ((1, 10),),
    "fLastLeg": ((1, 10),),
}


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            validate_finite(item, path + "[" + str(position) + "]")


def require_integer(value, path):
    if isinstance(value, bool):
        raise ValueError("Expected integer at " + path)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected integer at " + path)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution."
        )
    return variables[name]


def decode_index_set(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected encoded index set at " + path)

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))

    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        values = [
            require_integer(item, path + ".set")
            for item in elements
        ]
        if len(set(values)) != len(values):
            raise ValueError("Duplicate index at " + path)
        return sorted(values)

    raise ValueError("Invalid index-set encoding at " + path)


def copy_array(variables, name, domains):
    encoded = required_variable(variables, name)
    path = "variables." + name

    if not isinstance(encoded, dict):
        raise ValueError("Expected encoded array at " + path)
    if "array" not in encoded or "index_sets" not in encoded:
        raise ValueError("Missing array or index_sets at " + path)

    elements = encoded["array"]
    index_sets = encoded["index_sets"]

    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + path)
    if len(index_sets) != len(domains):
        raise ValueError("Incorrect number of dimensions at " + path)

    count = 1
    for dimension, (lower, upper) in enumerate(domains):
        actual = decode_index_set(
            index_sets[dimension],
            path + ".index_sets[" + str(dimension) + "]",
        )
        expected = list(range(lower, upper + 1))
        if actual != expected:
            raise ValueError("Incorrect index domain at " + path)
        count *= len(expected)

    if len(elements) != count:
        raise ValueError("Incorrect element count at " + path)

    return {
        "array": [
            require_integer(item, path + ".array[" + str(position) + "]")
            for position, item in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = payload["variables"]
    restored = {}

    for name, fixed_value in FIXED_COORDINATES.items():
        if name in variables and variables[name] is not None:
            restored[name] = require_integer(variables[name], "variables." + name)
        else:
            restored[name] = fixed_value

    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            restored[name] = require_integer(
                required_variable(variables, name),
                "variables." + name,
            )

    for name, domains in RETAINED_ARRAYS.items():
        restored[name] = copy_array(variables, name, domains)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        restored["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required "
            "to restore the original objective variable."
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    validate_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)