import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def map_solution(data):
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Required field 'variables' must be a JSON object.")

    source = data["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 43,
        "nXNd__1_1_Z": 82,
        "nXNd__1_10_X": 293,
        "nXNd__1_10_Y": 25,
        "nXNd__1_10_Z": 3,
    }

    coordinate_names = [
        "nXNd__1_{}_{}".format(node, axis)
        for node in range(1, 11)
        for axis in ("X", "Y", "Z")
    ]

    for name in coordinate_names:
        if name in source and source[name] is not None:
            result[name] = source[name]
        elif name in fixed_coordinates:
            result[name] = fixed_coordinates[name]
        else:
            raise ValueError(
                "Missing required field variables." + name +
                "; this retained coordinate must come from default DZN output."
            )

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        if name not in source or source[name] is None:
            raise ValueError(
                "Missing required field variables." + name +
                "; this retained array must come from default DZN output."
            )
        value = source[name]
        if not isinstance(value, dict):
            raise ValueError("Expected encoded MiniZinc array at variables." + name)
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "Required array encoding fields are missing at variables." + name
            )
        result[name] = value

    if "obj" in source and source["obj"] is not None:
        result["obj"] = source["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("Field 'objective' must be numeric.")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("Field 'objective' must be a finite integer.")
        result["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing required field variables.obj or objective; "
            "the original objective is retained without scaling changes."
        )

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        data = json.load(
            handle,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object.")

    check_finite(data, "input")
    mapped = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(mapped, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    main()