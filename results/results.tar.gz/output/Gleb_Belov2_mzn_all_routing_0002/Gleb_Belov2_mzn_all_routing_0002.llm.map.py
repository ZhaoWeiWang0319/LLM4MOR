import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from default DZN solver output".format(name)
        )
    return variables[name]


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(path + " must be a JSON integer")
    return value


def index_members(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError(path + " must be an encoded index set")
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(path + ".range must contain two integers")
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(encoded) == {"set"}:
        members = encoded["set"]
        if not isinstance(members, list):
            raise ValueError(path + ".set must be a list")
        for member in members:
            require_integer(member, path + ".set")
        if members != sorted(set(members)):
            raise ValueError(path + ".set must be sorted and contain no duplicates")
        return members
    raise ValueError(path + " must use set or range encoding")


def require_array(variables, name, expected_domains):
    value = require_variable(variables, name)
    if not isinstance(value, dict):
        raise ValueError("variables." + name + " must be an encoded array")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables." + name + " requires array and index_sets fields"
        )
    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(domains, list):
        raise ValueError("Invalid array encoding for variables." + name)
    if len(domains) != len(expected_domains):
        raise ValueError("Wrong number of dimensions for variables." + name)

    count = 1
    for dimension, (domain, expected) in enumerate(zip(domains, expected_domains)):
        members = index_members(
            domain, "variables.{}.index_sets[{}]".format(name, dimension)
        )
        if members != expected:
            raise ValueError("Incorrect index domain for variables." + name)
        count *= len(members)

    if len(elements) != count:
        raise ValueError("Incorrect element count for variables." + name)
    for position, element in enumerate(elements):
        require_integer(
            element, "variables.{}.array[{}]".format(name, position)
        )
    return {"array": elements, "index_sets": domains}


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = document["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 309,
        "nXNd__1_1_Y": 54,
        "nXNd__1_1_Z": 101,
        "nXNd__1_10_X": 153,
        "nXNd__1_10_Y": 51,
        "nXNd__1_10_Z": 38,
    }

    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            if name in variables and variables[name] is not None:
                restored[name] = require_integer(
                    variables[name], "variables." + name
                )
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = require_integer(
                    require_variable(variables, name), "variables." + name
                )

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        restored[name] = require_array(
            variables, name, [node_domain, coordinate_domain]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        restored[name] = require_array(variables, name, [node_domain])

    restored["obj"] = require_integer(
        require_variable(variables, "obj"), "variables.obj"
    )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    main()