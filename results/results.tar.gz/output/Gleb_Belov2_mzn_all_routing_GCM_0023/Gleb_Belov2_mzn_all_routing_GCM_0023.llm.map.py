import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 275,
    "nXNd__1_1_Y": 54,
    "nXNd__1_1_Z": 8,
    "nXNd__1_10_X": 255,
    "nXNd__1_10_Y": 52,
    "nXNd__1_10_Z": 143,
}

FREE_COORDINATES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(2, 10)
    for axis in ("X", "Y", "Z")
)

ORIGINAL_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the reformulated model's "
            "default DZN solution output".format(name)
        )
    return variables[name]


def index_cardinality(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Invalid index-set encoding at " + path)

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(bound) is not int for bound in bounds)
        ):
            raise ValueError("Invalid range encoding at " + path)
        return max(0, bounds[1] - bounds[0] + 1)

    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if (
            not isinstance(elements, list)
            or any(type(element) is not int for element in elements)
            or len(set(elements)) != len(elements)
        ):
            raise ValueError("Invalid integer-set encoding at " + path)
        return len(elements)

    raise ValueError("Invalid index-set encoding at " + path)


def validate_array(value, name):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets field at " + path)
    if not isinstance(value["array"], list):
        raise ValueError("Expected flattened array list at " + path)
    if not isinstance(value["index_sets"], list):
        raise ValueError("Expected index_sets list at " + path)

    dimensions = 2 if name in ("nXLeg1", "nXLeg2", "nLLeg") else 1
    if len(value["index_sets"]) != dimensions:
        raise ValueError("Incorrect array dimension at " + path)

    size = 1
    for dimension, encoded in enumerate(value["index_sets"]):
        size *= index_cardinality(
            encoded, "{}.index_sets[{}]".format(path, dimension)
        )
    if size != len(value["array"]):
        raise ValueError("Array length does not match its index sets at " + path)
    if any(type(element) is not int for element in value["array"]):
        raise ValueError("Expected integer array elements at " + path)


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = document["variables"]
    restored = dict(FIXED_COORDINATES)

    for name in FREE_COORDINATES:
        value = required_variable(variables, name)
        if type(value) is not int:
            raise ValueError("Expected integer at variables." + name)
        restored[name] = value

    for name in ORIGINAL_ARRAYS:
        value = required_variable(variables, name)
        validate_array(value, name)
        restored[name] = value

    value = required_variable(variables, "obj")
    if type(value) is not int:
        raise ValueError("Expected integer at variables.obj")
    restored["obj"] = value

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)