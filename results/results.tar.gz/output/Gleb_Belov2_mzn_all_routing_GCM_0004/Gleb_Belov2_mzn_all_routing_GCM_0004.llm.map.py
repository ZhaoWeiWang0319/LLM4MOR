import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 212,
    "nXNd__1_1_Y": 58,
    "nXNd__1_1_Z": 115,
    "nXNd__1_10_X": 245,
    "nXNd__1_10_Y": 43,
    "nXNd__1_10_Z": 113,
}

ORIGINAL_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution."
        )
    return variables[name]


def integer_value(value, path):
    if isinstance(value, bool):
        raise ValueError("Expected an integer at " + path)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected a finite integer at " + path)


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = payload["variables"]
    restored = {}

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = integer_value(variables[name], "variables." + name)
            elif name in FIXED_ENDPOINTS:
                restored[name] = FIXED_ENDPOINTS[name]
            else:
                restored[name] = integer_value(
                    require_variable(variables, name),
                    "variables." + name,
                )

    for name in ORIGINAL_ARRAYS:
        value = require_variable(variables, name)
        if not isinstance(value, dict):
            raise ValueError(
                "variables." + name
                + " must use the MiniZinc array encoding."
            )
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables." + name
                + " must contain array and index_sets."
            )
        if not isinstance(value["array"], list):
            raise ValueError("Invalid array elements for variables." + name)
        if not isinstance(value["index_sets"], list):
            raise ValueError("Invalid index_sets for variables." + name)
        restored[name] = {
            "array": [
                integer_value(item, "variables." + name + ".array[" + str(i) + "]")
                for i, item in enumerate(value["array"])
            ],
            "index_sets": value["index_sets"],
        }

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = integer_value(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        restored["obj"] = integer_value(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; the unchanged integer "
            "objective is required from the reformulated solution."
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        sys.stderr.write("Mapping error: " + str(error) + "\n")
        sys.exit(1)