import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 308,
    "nXNd__1_1_Y": 25,
    "nXNd__1_1_Z": 3,
    "nXNd__1_10_X": 308,
    "nXNd__1_10_Y": 47,
    "nXNd__1_10_Z": 48,
}

ARRAY_VARIABLES = {
    "nXLeg1": (10, 3),
    "nXLeg2": (10, 3),
    "nLLeg": (10, 3),
    "nDirLeg": (10,),
    "fExistLeg": (10,),
    "fLastLeg": (10,),
}


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("Expected an integer at " + path)
    return value


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        elements = [
            require_integer(item, path + ".set")
            for item in elements
        ]
        if len(set(elements)) != len(elements):
            raise ValueError("Duplicate index at " + path)
        return sorted(elements)
    raise ValueError("Invalid index-set encoding at " + path)


def copy_array(value, name, shape):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    domains = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(domains, list):
        raise ValueError("Invalid array encoding at " + path)
    if len(domains) != len(shape):
        raise ValueError("Incorrect number of dimensions at " + path)
    expected_size = 1
    for dimension, size in enumerate(shape):
        actual = decode_index_set(
            domains[dimension],
            "{}.index_sets[{}]".format(path, dimension),
        )
        if actual != list(range(1, size + 1)):
            raise ValueError("Incorrect index domain at " + path)
        expected_size *= size
    if len(elements) != expected_size:
        raise ValueError("Incorrect element count at " + path)
    for index, element in enumerate(elements):
        require_integer(element, "{}.array[{}]".format(path, index))
    return {"array": list(elements), "index_sets": domains}


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing required object: variables")

    source = payload["variables"]
    restored = {}

    # The dimensions and fixed coordinates below are from the original
    # self-contained model, not from an external data file.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in source and source[name] is not None:
                restored[name] = require_integer(
                    source[name], "variables." + name
                )
            elif name in FIXED_COORDINATES:
                restored[name] = FIXED_COORDINATES[name]
            else:
                raise ValueError(
                    "Missing required field variables.{} "
                    "from the default DZN solution".format(name)
                )

    for name, shape in ARRAY_VARIABLES.items():
        if name not in source or source[name] is None:
            raise ValueError(
                "Missing required field variables.{} "
                "from the default DZN solution".format(name)
            )
        restored[name] = copy_array(source[name], name, shape)

    if "obj" in source and source["obj"] is not None:
        restored["obj"] = require_integer(source["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("Expected a finite integer-valued objective")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("Expected a finite integer-valued objective")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj from the default DZN solution "
            "and missing non-null objective"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        payload = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)