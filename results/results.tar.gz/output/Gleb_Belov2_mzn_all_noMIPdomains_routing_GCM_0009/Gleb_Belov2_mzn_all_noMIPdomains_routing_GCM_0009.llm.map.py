import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 309,
    "nXNd__1_1_Y": 106,
    "nXNd__1_1_Z": 80,
    "nXNd__1_10_X": 302,
    "nXNd__1_10_Y": 60,
    "nXNd__1_10_Z": 54,
}

RETAINED_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required source is the reformulated "
            "model's default DZN solution.".format(name)
        )
    return variables[name]


def restore(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in document:
        raise ValueError("Missing variables field.")
    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object.")

    restored = {}

    for name, fixed_value in FIXED_COORDINATES.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            restored[name] = required(variables, name)

    for name in RETAINED_ARRAYS:
        restored[name] = required(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    else:
        if "objective" not in document or document["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; the unchanged original "
                "objective must be supplied by the reformulated solution."
            )
        value = document["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("objective must be a finite integer-valued number.")
        if isinstance(value, float):
            if not math.isfinite(value) or not value.is_integer():
                raise ValueError("objective must be a finite integer-valued number.")
        restored["obj"] = int(value)

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        document = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(document, "input")
    result = restore(document)

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(result, stream, allow_nan=False, separators=(",", ":"))
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)