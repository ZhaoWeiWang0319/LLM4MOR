import json
import math
import sys


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution."
        )
    return variables[name]


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = document["variables"]
    restored = {}

    # These constants are the original self-contained endpoint declarations.
    fixed_coordinates = {
        "nXNd__1_1_X": 308,
        "nXNd__1_1_Y": 47,
        "nXNd__1_1_Z": 43,
        "nXNd__1_10_X": 298,
        "nXNd__1_10_Y": 25,
        "nXNd__1_10_Z": 3,
    }

    # The original self-contained model declares exactly these ten nodes.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = require_variable(variables, name)

    # These independent arrays retain their original names and index domains.
    # Copy their full encoded values, including all index-set metadata.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        restored[name] = require_variable(variables, name)

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        document = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(document, "input")
    result = map_solution(document)
    check_finite(result, "output")
    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(result, stream, allow_nan=False, separators=(",", ":"))
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)