import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 211,
    "nXNd__1_1_Y": 48,
    "nXNd__1_1_Z": 5,
    "nXNd__1_10_X": 210,
    "nXNd__1_10_Y": 77,
    "nXNd__1_10_Z": 45,
}

REQUIRED_SCALARS = (
    "nXNd__1_2_X",
    "nXNd__1_2_Y",
    "nXNd__1_2_Z",
    "nXNd__1_3_X",
    "nXNd__1_3_Y",
    "nXNd__1_3_Z",
    "nXNd__1_4_X",
    "nXNd__1_4_Y",
    "nXNd__1_4_Z",
    "nXNd__1_5_X",
    "nXNd__1_5_Y",
    "nXNd__1_5_Z",
    "nXNd__1_6_X",
    "nXNd__1_6_Y",
    "nXNd__1_6_Z",
    "nXNd__1_7_X",
    "nXNd__1_7_Y",
    "nXNd__1_7_Z",
    "nXNd__1_8_X",
    "nXNd__1_8_Y",
    "nXNd__1_8_Z",
    "nXNd__1_9_X",
    "nXNd__1_9_Y",
    "nXNd__1_9_Z",
    "obj",
)

REQUIRED_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite JSON number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{} "
            "from the reformulated model's default DZN solution".format(name)
        )
    return variables[name]


def check_integer(value, path):
    if type(value) is not int:
        raise ValueError("Expected an integer at " + path)


def index_cardinality(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range encoding at " + path)
        lower, upper = bounds
        check_integer(lower, path + ".range[0]")
        check_integer(upper, path + ".range[1]")
        return max(0, upper - lower + 1)
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set encoding at " + path)
        for index, element in enumerate(elements):
            check_integer(element, "{}.set[{}]".format(path, index))
        if len(set(elements)) != len(elements):
            raise ValueError("Duplicate index-set element at " + path)
        return len(elements)
    raise ValueError("Invalid index-set encoding at " + path)


def check_array(value, name):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    indices = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(indices, list):
        raise ValueError("Invalid array encoding at " + path)
    dimensions = 2 if name in ("nXLeg1", "nXLeg2", "nLLeg") else 1
    if len(indices) != dimensions:
        raise ValueError("Incorrect number of dimensions at " + path)
    expected = 1
    for dimension, encoded in enumerate(indices):
        expected *= index_cardinality(
            encoded, "{}.index_sets[{}]".format(path, dimension)
        )
    if len(elements) != expected:
        raise ValueError("Array element count does not match index sets at " + path)
    for index, element in enumerate(elements):
        check_integer(element, "{}.array[{}]".format(path, index))


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Expected a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid required field variables")
    variables = document["variables"]
    restored = {}

    for name, fixed_value in FIXED_ENDPOINTS.items():
        if name in variables and variables[name] is not None:
            check_integer(variables[name], "variables." + name)
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for name in REQUIRED_SCALARS:
        value = required_value(variables, name)
        check_integer(value, "variables." + name)
        restored[name] = value

    for name in REQUIRED_ARRAYS:
        value = required_value(variables, name)
        check_array(value, name)
        restored[name] = value

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(document, "input")
    result = map_solution(document)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)