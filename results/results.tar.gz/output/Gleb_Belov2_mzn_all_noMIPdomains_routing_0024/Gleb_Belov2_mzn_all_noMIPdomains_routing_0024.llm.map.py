import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 185,
    "nXNd__1_1_Y": 53,
    "nXNd__1_1_Z": 58,
    "nXNd__1_10_X": 288,
    "nXNd__1_10_Y": 25,
    "nXNd__1_10_Z": 3,
}

COORDINATE_NAMES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}: required from default DZN solution output"
            .format(name)
        )
    return variables[name]


def integer_value(value, path):
    if isinstance(value, bool):
        raise ValueError("Expected an integer at " + path)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected an integer at " + path)


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    restored = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            restored[name] = integer_value(
                variables[name], "variables." + name
            )
        elif name in FIXED_COORDINATES:
            restored[name] = FIXED_COORDINATES[name]
        else:
            require_variable(variables, name)

    for name in ARRAY_NAMES:
        value = require_variable(variables, name)
        if not isinstance(value, dict):
            raise ValueError("Expected encoded array at variables." + name)
        if "array" not in value or not isinstance(value["array"], list):
            raise ValueError("Missing array elements at variables." + name)
        if "index_sets" not in value or not isinstance(value["index_sets"], list):
            raise ValueError("Missing index_sets at variables." + name)
        restored[name] = {
            "array": [
                integer_value(
                    item, "variables.{}.array[{}]".format(name, position)
                )
                for position, item in enumerate(value["array"])
            ],
            "index_sets": value["index_sets"],
        }

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = integer_value(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        restored["obj"] = integer_value(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective: one is required to restore obj"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")
    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump(result, stream, allow_nan=False, separators=(",", ":"))
        stream.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)