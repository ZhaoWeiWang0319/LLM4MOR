import json
import math
import sys


CALENDAR = [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27]
DURATION = [3, 1, 2, 2, 1, 1, 2, 3, 4, 3, 1, 1]
CAPACITY = [2, 4, 0, 1, 2, 0, 0, 2, 4, 0, 1, 2]
BASE = [0, 18, 39, 61, 84, 108, 133, 159, 186, 214, 243, 273]


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def decode_index(value, field):
    if not isinstance(value, dict):
        raise ValueError(field + " must be an encoded index set")
    if set(value) == {"range"}:
        bounds = value["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(x) is not int for x in bounds)
        ):
            raise ValueError("Invalid range in " + field)
        return list(range(bounds[0], bounds[1] + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if (
            not isinstance(elements, list)
            or any(type(x) is not int for x in elements)
            or len(set(elements)) != len(elements)
        ):
            raise ValueError("Invalid set in " + field)
        return sorted(elements)
    raise ValueError("Invalid index-set encoding in " + field)


def read_array(variables, name, size):
    if name not in variables:
        raise ValueError(
            "Missing variables." + name +
            "; required from the reformulated model's default DZN solution"
        )
    encoded = variables[name]
    if not isinstance(encoded, dict):
        raise ValueError("variables." + name + " must be an encoded array")
    if "array" not in encoded or "index_sets" not in encoded:
        raise ValueError("Incomplete array encoding for variables." + name)
    elements = encoded["array"]
    indices = encoded["index_sets"]
    if not isinstance(elements, list) or len(elements) != size:
        raise ValueError("Incorrect element count for variables." + name)
    if not isinstance(indices, list) or len(indices) != 1:
        raise ValueError("Incorrect dimension count for variables." + name)
    if decode_index(indices[0], name + ".index_sets[0]") != list(
        range(1, size + 1)
    ):
        raise ValueError("Incorrect index domain for variables." + name)
    return elements


def reconstruct(payload):
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    n = len(DURATION)
    days = read_array(payload["variables"], "pp12r_day", n)
    outsourced = read_array(payload["variables"], "pp12r_out", n)

    for value in days:
        if type(value) is not int or not 1 <= value <= len(CALENDAR):
            raise ValueError("pp12r_day entries must be valid day indices")
    for value in outsourced:
        if type(value) is not bool:
            raise ValueError("pp12r_out entries must be Boolean")

    restored = {}

    def put(prefix, suffix, value):
        name = prefix + str(suffix)
        if name in restored:
            raise ValueError("Duplicate reconstructed variable: " + name)
        restored[name] = value

    loads = [0] * len(CALENDAR)
    ranks = []
    count = 0

    for task, base in enumerate(BASE):
        k = task + 1
        day_index = days[task]
        position = day_index - 1
        selected = outsourced[task]

        put("chooseDay", base, CALENDAR[position])
        put("chooseBool", base + 1, selected)

        if task == 0:
            count = int(selected)
            ranks = [0]
            put("ite", 2, count)
            put("index", 3, day_index)

            if not selected:
                loads[position] += DURATION[task]

            for offset, value in enumerate(loads):
                put("hoursAssigned", 4 + offset, value)
            put("hoursAssigned", 16, loads[position])
            put("maxHours", 17, CAPACITY[position])
        else:
            previous_count = count
            new_rank = previous_count if selected else task
            put("ite", base + 2, new_rank)

            updated_ranks = [
                rank + int(selected and rank >= previous_count)
                for rank in ranks
            ]
            for offset, value in enumerate(updated_ranks):
                put("ite", base + 3 + offset, value)

            ranks = updated_ranks + [new_rank]
            count = previous_count + int(selected)

            put("ite", base + k + 2, count)
            put("index", base + k + 3, day_index)
            put("hoursAssigned", base + k + 4, loads[position])

            if not selected:
                loads[position] += DURATION[task]

            for offset, value in enumerate(loads):
                put("hoursAssigned", base + k + 5 + offset, value)
            put("hoursAssigned", base + k + 17, loads[position])
            put("maxHours", base + k + 18, CAPACITY[position])

    day_number_tasks = [4, 2, 6, 1, 8, 3, 10, 11, 9, 12]
    for offset, task_number in enumerate(day_number_tasks):
        put("dayNumber", 304 + offset, days[task_number - 1])

    inverse_values = []
    for rank_value in range(n):
        value = n + 1
        for step, task in enumerate(range(n - 2, -1, -1)):
            if ranks[task] == rank_value:
                value = task + 2
            put("ite", 314 + (n - 1) * rank_value + step, value)
        inverse_values.append(value)

    cost = 5 * len({
        days[task] for task in range(n) if outsourced[task]
    })
    for rank_value, inverse_value in enumerate(inverse_values):
        lookup_index = inverse_value - 1
        duration = DURATION[lookup_index - 1]
        put("index", 446 + 3 * rank_value, lookup_index)
        put("duration", 447 + 3 * rank_value, duration)
        if count > rank_value:
            cost += 2 * duration
        put("ite", 448 + 3 * rank_value, cost)

    expected_cost = (
        5 * len({days[t] for t in range(n) if outsourced[t]})
        + 2 * sum(DURATION[t] for t in range(n) if outsourced[t])
    )
    if cost != expected_cost:
        raise ValueError("Reconstructed objective is inconsistent")

    suffixes = []
    for name, value in restored.items():
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("Non-finite reconstructed value: " + name)
        start = len(name)
        while start > 0 and name[start - 1].isdigit():
            start -= 1
        suffixes.append(int(name[start:]))

    if sorted(suffixes) != list(range(482)):
        raise ValueError("Incomplete reconstruction of original variables")

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    result = reconstruct(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()