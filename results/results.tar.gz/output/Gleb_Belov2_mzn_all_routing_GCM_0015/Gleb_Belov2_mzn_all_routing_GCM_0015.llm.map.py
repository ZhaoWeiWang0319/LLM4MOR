import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 212,
    "nXNd__1_1_Y": 36,
    "nXNd__1_1_Z": 100,
    "nXNd__1_10_X": 245,
    "nXNd__1_10_Y": 43,
    "nXNd__1_10_Z": 58,
}

UNFIXED_COORDINATES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(2, 10)
    for axis in ("X", "Y", "Z")
)

ORIGINAL_ARRAYS = {
    "nXLeg1": 2,
    "nXLeg2": 2,
    "nLLeg": 2,
    "nDirLeg": 1,
    "fExistLeg": 1,
    "fLastLeg": 1,
}


def reject_constant(value):
    raise ValueError("Invalid nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def integer_value(value, path):
    if isinstance(value, bool):
        raise ValueError(path + " must be an integer, not a Boolean")
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(path + " must contain a finite integer value")


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{}; "
            "it must be emitted by the reformulated model's default DZN output"
            .format(name)
        )
    return variables[name]


def index_cardinality(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError(path + " must use the MiniZinc set encoding")

    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(path + ".range must have two integer bounds")
        lower = integer_value(bounds[0], path + ".range[0]")
        upper = integer_value(bounds[1], path + ".range[1]")
        return max(0, upper - lower + 1)

    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError(path + ".set must be a list")
        normalized = [
            integer_value(item, "{}.set[{}]".format(path, index))
            for index, item in enumerate(elements)
        ]
        if normalized != sorted(set(normalized)):
            raise ValueError(path + ".set must contain sorted, distinct integers")
        return len(normalized)

    raise ValueError(path + " must contain exactly 'range' or 'set'")


def copy_integer_array(value, dimensions, path):
    if not isinstance(value, dict):
        raise ValueError(path + " must use the MiniZinc array encoding")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(path + " requires both 'array' and 'index_sets'")

    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError(path + ".array must be a list")
    if not isinstance(index_sets, list) or len(index_sets) != dimensions:
        raise ValueError(
            "{}.index_sets must contain {} dimensions".format(path, dimensions)
        )

    expected = 1
    for dimension, encoded in enumerate(index_sets):
        expected *= index_cardinality(
            encoded, "{}.index_sets[{}]".format(path, dimension)
        )
    if len(elements) != expected:
        raise ValueError(
            "{} has {} elements, but its index sets require {}"
            .format(path, len(elements), expected)
        )

    return {
        "array": [
            integer_value(item, "{}.array[{}]".format(path, index))
            for index, item in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(payload, "input")

    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")
    variables = payload["variables"]
    restored = {}

    for name, fixed_value in FIXED_COORDINATES.items():
        restored[name] = fixed_value

    for name in UNFIXED_COORDINATES:
        restored[name] = integer_value(
            required_variable(variables, name), "variables." + name
        )

    for name, dimensions in ORIGINAL_ARRAYS.items():
        restored[name] = copy_integer_array(
            required_variable(variables, name), dimensions, "variables." + name
        )

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = integer_value(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        restored["obj"] = integer_value(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing required field variables.obj or objective; "
            "the original obj equals the reformulated solver objective"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError, KeyError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)