import json
import math
import sys


def reject_constant(value):
    raise ValueError("Nonfinite JSON constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            validate_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the model's default DZN "
            "solution output.".format(name)
        )
    return variables[name]


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = document["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 43,
        "nXNd__1_1_Z": 122,
        "nXNd__1_10_X": 212,
        "nXNd__1_10_Y": 52,
        "nXNd__1_10_Z": 100,
    }

    for name, fixed_value in fixed_coordinates.items():
        if name in variables and variables[name] is not None:
            result[name] = variables[name]
        else:
            result[name] = fixed_value

    nonfixed_coordinates = (
        "nXNd__1_2_X", "nXNd__1_2_Y", "nXNd__1_2_Z",
        "nXNd__1_3_X", "nXNd__1_3_Y", "nXNd__1_3_Z",
        "nXNd__1_4_X", "nXNd__1_4_Y", "nXNd__1_4_Z",
        "nXNd__1_5_X", "nXNd__1_5_Y", "nXNd__1_5_Z",
        "nXNd__1_6_X", "nXNd__1_6_Y", "nXNd__1_6_Z",
        "nXNd__1_7_X", "nXNd__1_7_Y", "nXNd__1_7_Z",
        "nXNd__1_8_X", "nXNd__1_8_Y", "nXNd__1_8_Z",
        "nXNd__1_9_X", "nXNd__1_9_Y", "nXNd__1_9_Z",
    )

    for name in nonfixed_coordinates:
        result[name] = require_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        value = require_variable(variables, name)
        if not isinstance(value, dict):
            raise ValueError("variables.{} must use the array encoding.".format(name))
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables.{} requires array and index_sets fields.".format(name)
            )
        if not isinstance(value["array"], list) or not isinstance(value["index_sets"], list):
            raise ValueError("Invalid array encoding for variables.{}.".format(name))
        if any(item is None for item in value["array"]):
            raise ValueError("Missing array element in variables.{}.".format(name))
        result[name] = value

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    else:
        if "objective" not in document or document["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; obj must come from "
                "the default DZN solution or its unchanged objective value."
            )
        objective = document["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number.")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number.")
        result["obj"] = int(objective)

    validate_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    validate_finite(document, "input")
    output = map_solution(document)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(output, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)