import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            validate_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            validate_finite(item, path + "[" + str(position) + "]")


def require(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution."
        )
    return variables[name]


def map_solution(document):
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object.")
    variables = document["variables"]

    # These values are fixed by the supplied self-contained instance.
    # Node 2 has the first nozzle's X and Y coordinates.
    # Node 9 has the final nozzle's X and Z coordinates, whether
    # the final potential leg exists or has zero length.
    fixed_coordinates = {
        "nXNd__1_1_X": 212,
        "nXNd__1_1_Y": 36,
        "nXNd__1_1_Z": 100,
        "nXNd__1_2_X": 212,
        "nXNd__1_2_Y": 36,
        "nXNd__1_9_X": 245,
        "nXNd__1_9_Z": 58,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 43,
        "nXNd__1_10_Z": 58,
    }

    restored = {}
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = require(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        value = require(variables, name)
        if (
            not isinstance(value, dict)
            or "array" not in value
            or "index_sets" not in value
        ):
            raise ValueError(
                "variables." + name
                + " must use the MiniZinc array encoding with index_sets."
            )
        restored[name] = value

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    else:
        if "objective" not in document or document["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; one is required "
                "from the reformulated solution."
            )
        objective = document["objective"]
        if (
            isinstance(objective, bool)
            or not isinstance(objective, (int, float))
            or (isinstance(objective, float) and not math.isfinite(objective))
            or objective != int(objective)
        ):
            raise ValueError("objective must be a finite integer for this model.")
        restored["obj"] = int(objective)

    result = {"variables": restored}
    validate_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    validate_finite(document, "input")
    result = map_solution(document)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False)
        destination.write("\n")


if __name__ == "__main__":
    main()