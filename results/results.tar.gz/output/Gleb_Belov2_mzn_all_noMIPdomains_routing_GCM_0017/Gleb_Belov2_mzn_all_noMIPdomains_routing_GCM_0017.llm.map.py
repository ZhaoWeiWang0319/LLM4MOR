import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 211,
    "nXNd__1_1_Y": 48,
    "nXNd__1_1_Z": 5,
    "nXNd__1_10_X": 210,
    "nXNd__1_10_Y": 77,
    "nXNd__1_10_Z": 45,
}

COORDINATE_NAMES = tuple(
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer at " + path)
    return int(value)


def index_elements(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(encoded) == {"set"}:
        values = encoded["set"]
        if not isinstance(values, list):
            raise ValueError("Invalid set at " + path)
        result = [
            require_integer(item, "{}.set[{}]".format(path, position))
            for position, item in enumerate(values)
        ]
        if len(set(result)) != len(result):
            raise ValueError("Duplicate index in " + path)
        return sorted(result)
    raise ValueError("Invalid encoded index set at " + path)


def copy_array(name, value, context):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets field at " + path)
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + path)
    dimensions = [
        index_elements(item, "{}.index_sets[{}]".format(path, position))
        for position, item in enumerate(index_sets)
    ]
    expected_count = math.prod(len(domain) for domain in dimensions)
    if len(elements) != expected_count:
        raise ValueError("Array element count does not match index sets at " + path)
    if name in context:
        original_sets = context[name]
        if not isinstance(original_sets, list):
            raise ValueError("Invalid indices." + name)
        original_dimensions = [
            index_elements(item, "indices.{}[{}]".format(name, position))
            for position, item in enumerate(original_sets)
        ]
        if dimensions != original_dimensions:
            raise ValueError("Original and reformulated index sets differ for " + name)
    return {
        "array": [
            require_integer(item, "{}.array[{}]".format(path, position))
            for position, item in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required input field: variables")
    variables = payload["variables"]
    if "indices" in payload:
        context = payload["indices"]
        if not isinstance(context, dict):
            raise ValueError("Invalid input field: indices")
    else:
        context = {}

    restored = {}
    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            restored[name] = require_integer(variables[name], "variables." + name)
        elif name in FIXED_COORDINATES:
            restored[name] = FIXED_COORDINATES[name]
        else:
            raise ValueError(
                "Missing required field variables.{} from default DZN output".format(name)
            )

    for name in ARRAY_NAMES:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables.{} from default DZN output".format(name)
            )
        restored[name] = copy_array(name, variables[name], context)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        restored["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing required field variables.obj from default DZN output "
            "and no solution objective is available"
        )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()