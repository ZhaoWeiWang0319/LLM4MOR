import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 245,
    "nXNd__1_1_Y": 108,
    "nXNd__1_1_Z": 115,
    "nXNd__1_10_X": 245,
    "nXNd__1_10_Y": 62,
    "nXNd__1_10_Z": 113,
}

ORIGINAL_ARRAYS = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Nonfinite number at " + path)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name +
            "; required from the reformulated model's default DZN solution."
        )
    return variables[name]


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = data["variables"]
    restored = {}

    for name, fixed_value in FIXED_ENDPOINTS.items():
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for node in range(2, 10):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            restored[name] = required_variable(variables, name)

    for name in ORIGINAL_ARRAYS:
        restored[name] = required_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    else:
        if "objective" not in data or data["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; one is required "
                "to restore the original objective variable."
            )
        objective = data["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number.")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number.")
        restored["obj"] = int(objective)

    result = {"variables": restored}
    check_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")
    result = map_solution(data)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)