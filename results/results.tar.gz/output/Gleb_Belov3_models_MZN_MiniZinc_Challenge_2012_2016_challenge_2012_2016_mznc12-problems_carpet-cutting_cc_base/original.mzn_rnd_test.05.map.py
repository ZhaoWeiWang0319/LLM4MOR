import json
import sys
required = ['RollLen', 'rm_ori_0_or_180', 'rm_ori_0_or_90', 'rm_rec_x', 'rm_rec_y', 'rm_vori', 'rm_x', 'rm_y', 'st_rec_x', 'st_rec_y']
with open(sys.argv[1], encoding='utf-8') as stream:
    solution = json.load(stream)
with open(sys.argv[2], 'w', encoding='utf-8') as stream:
    json.dump({'variables': {name: solution['variables'][name] for name in required}}, stream, allow_nan=False)
