import json
import math
import sys


FIXED_COORDINATES = {
    "nXNd__1_1_X": 309,
    "nXNd__1_1_Y": 106,
    "nXNd__1_1_Z": 80,
    "nXNd__1_10_X": 302,
    "nXNd__1_10_Y": 60,
    "nXNd__1_10_Z": 54,
}

COORDINATE_NAMES = [
    "nXNd__1_{}_{}".format(node, axis)
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
]

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{}; expected in the "
            "reformulated model's default DZN solution".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = payload["variables"]
    restored = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in FIXED_COORDINATES:
            restored[name] = FIXED_COORDINATES[name]
        else:
            restored[name] = require_variable(variables, name)

    for name in ARRAY_NAMES:
        value = require_variable(variables, name)
        if not isinstance(value, dict):
            raise ValueError(
                "variables.{} must use MiniZinc array encoding".format(name)
            )
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                "variables.{} requires array and index_sets fields".format(name)
            )
        restored[name] = value

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in payload and payload["objective"] is not None:
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number")
        if isinstance(objective, float) and not objective.is_integer():
            raise ValueError("objective must be integer-valued")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing required field variables.obj or objective; "
            "the reformulated objective is the original obj"
        )

    result = {"variables": restored}
    check_finite(result, "output")
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        sys.stderr.write("Mapping error: {}\n".format(error))
        sys.exit(1)