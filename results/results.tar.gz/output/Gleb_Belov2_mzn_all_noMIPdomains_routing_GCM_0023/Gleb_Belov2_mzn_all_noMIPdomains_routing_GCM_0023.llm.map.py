import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{}; expected in the "
            "reformulated model's default DZN solution.".format(name)
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field: variables")

    variables = payload["variables"]
    restored = {}

    # These values are the singleton coordinate domains in the original
    # self-contained model. Fixed scalars need not be emitted by MiniZinc.
    fixed_coordinates = {
        "nXNd__1_1_X": 275,
        "nXNd__1_1_Y": 54,
        "nXNd__1_1_Z": 8,
        "nXNd__1_10_X": 255,
        "nXNd__1_10_Y": 52,
        "nXNd__1_10_Z": 143,
    }

    # The original self-contained model declares precisely these ten nodes.
    # Every nonfixed original coordinate remains an independent scalar
    # declaration in the reformulated model.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = required_variable(variables, name)

    # These original independent arrays and the objective variable retain
    # their original names, meanings, dimensions, and index domains.
    # Copy the supplied MiniZinc JSON encodings, including index_sets.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        restored[name] = required_variable(variables, name)

    # Original declarations bound by "=" are recomputed by the original
    # model and are deliberately omitted, as are reformulation auxiliaries.
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)
    check_finite(result, "output")

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: {}".format(error), file=sys.stderr)
        sys.exit(1)