import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name +
            "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(payload, "input")

    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = payload["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 212,
        "nXNd__1_1_Y": 36,
        "nXNd__1_1_Z": 100,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 43,
        "nXNd__1_10_Z": 58,
    }

    coordinate_names = (
        "nXNd__1_1_X", "nXNd__1_1_Y", "nXNd__1_1_Z",
        "nXNd__1_2_X", "nXNd__1_2_Y", "nXNd__1_2_Z",
        "nXNd__1_3_X", "nXNd__1_3_Y", "nXNd__1_3_Z",
        "nXNd__1_4_X", "nXNd__1_4_Y", "nXNd__1_4_Z",
        "nXNd__1_5_X", "nXNd__1_5_Y", "nXNd__1_5_Z",
        "nXNd__1_6_X", "nXNd__1_6_Y", "nXNd__1_6_Z",
        "nXNd__1_7_X", "nXNd__1_7_Y", "nXNd__1_7_Z",
        "nXNd__1_8_X", "nXNd__1_8_Y", "nXNd__1_8_Z",
        "nXNd__1_9_X", "nXNd__1_9_Y", "nXNd__1_9_Z",
        "nXNd__1_10_X", "nXNd__1_10_Y", "nXNd__1_10_Z",
    )

    for name in coordinate_names:
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in fixed_coordinates:
            restored[name] = fixed_coordinates[name]
        else:
            restored[name] = required_variable(variables, name)

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        restored[name] = required_variable(variables, name)

    result = {"variables": restored}
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, TypeError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)