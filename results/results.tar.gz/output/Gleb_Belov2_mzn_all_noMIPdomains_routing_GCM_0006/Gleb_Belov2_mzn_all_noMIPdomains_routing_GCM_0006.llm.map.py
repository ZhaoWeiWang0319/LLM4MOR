import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def validate_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for index, element in enumerate(value):
            validate_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            validate_finite(element, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the model's default DZN "
            "solution output".format(name)
        )
    return variables[name]


def index_size(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Invalid index-set encoding at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if (
            not isinstance(bounds, list)
            or len(bounds) != 2
            or any(type(item) is not int for item in bounds)
        ):
            raise ValueError("Invalid integer range at " + path)
        return max(0, bounds[1] - bounds[0] + 1)
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set encoding at " + path)
        if any(type(item) is not int for item in elements):
            raise ValueError("Expected integer indices at " + path)
        if len(elements) != len(set(elements)):
            raise ValueError("Duplicate indices at " + path)
        return len(elements)
    raise ValueError("Invalid index-set encoding at " + path)


def require_integer(value, path):
    if type(value) is not int:
        raise ValueError("Expected an integer at " + path)
    return value


def require_integer_array(variables, name, dimensions):
    value = require_variable(variables, name)
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded MiniZinc array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + path)
    if len(index_sets) != dimensions:
        raise ValueError("Incorrect array dimensionality at " + path)
    expected = 1
    for axis, encoded in enumerate(index_sets):
        expected *= index_size(
            encoded, "{}.index_sets[{}]".format(path, axis)
        )
    if len(elements) != expected:
        raise ValueError("Array size does not match index sets at " + path)
    for position, element in enumerate(elements):
        require_integer(element, "{}.array[{}]".format(path, position))
    return {"array": elements, "index_sets": index_sets}


def map_solution(document):
    if not isinstance(document, dict):
        raise ValueError("The input must be a JSON object")
    if "variables" not in document or not isinstance(document["variables"], dict):
        raise ValueError("Missing or invalid variables object")

    variables = document["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 108,
        "nXNd__1_1_Z": 115,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 62,
        "nXNd__1_10_Z": 113,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                restored[name] = require_integer(
                    variables[name], "variables." + name
                )
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                restored[name] = require_integer(
                    require_variable(variables, name), "variables." + name
                )

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        restored[name] = require_integer_array(variables, name, 2)

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        restored[name] = require_integer_array(variables, name, 1)

    restored["obj"] = require_integer(
        require_variable(variables, "obj"), "variables.obj"
    )

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        document = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    validate_finite(document, "input")
    result = map_solution(document)

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(result, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    main()