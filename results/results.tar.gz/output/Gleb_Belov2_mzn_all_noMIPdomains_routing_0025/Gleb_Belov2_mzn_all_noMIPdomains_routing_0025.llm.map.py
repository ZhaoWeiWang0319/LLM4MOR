import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def require_integer(value, field):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(field + " must be a finite integer")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; required source: default DZN solution"
        )
    return variables[name]


def index_values(encoded, field):
    if not isinstance(encoded, dict):
        raise ValueError(field + " must use the MiniZinc index-set encoding")
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two bounds")
        lower = require_integer(bounds[0], field + ".range[0]")
        upper = require_integer(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))
    if set(encoded) == {"set"}:
        values = encoded["set"]
        if not isinstance(values, list):
            raise ValueError(field + ".set must be a list")
        result = [
            require_integer(value, field + ".set")
            for value in values
        ]
        if result != sorted(set(result)):
            raise ValueError(field + ".set must be sorted and unique")
        return result
    raise ValueError(field + " has invalid index-set encoding")


def copy_integer_array(variables, name, expected_indices):
    value = require_variable(variables, name)
    if not isinstance(value, dict):
        raise ValueError("variables." + name + " must be an encoded array")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables." + name + " must contain array and index_sets"
        )
    elements = value["array"]
    indices = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(indices, list):
        raise ValueError("Invalid array encoding for variables." + name)
    actual_indices = [
        index_values(encoded, "variables." + name + ".index_sets")
        for encoded in indices
    ]
    if actual_indices != expected_indices:
        raise ValueError("Incorrect original index domains for variables." + name)
    count = math.prod(len(domain) for domain in actual_indices)
    if len(elements) != count:
        raise ValueError("Incorrect element count for variables." + name)
    return {
        "array": [
            require_integer(element, "variables." + name + ".array")
            for element in elements
        ],
        "index_sets": indices,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid required field variables")

    variables = payload["variables"]

    # These singleton domains are fixed in the original self-contained model.
    result = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 43,
        "nXNd__1_1_Z": 82,
        "nXNd__1_10_X": 293,
        "nXNd__1_10_Y": 25,
        "nXNd__1_10_Z": 3,
    }

    # The original embedded instance has ten nodes and three coordinates.
    for node in range(2, 10):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            result[name] = require_integer(
                require_variable(variables, name),
                "variables." + name,
            )

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = copy_integer_array(
            variables, name, [node_domain, coordinate_domain]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = copy_integer_array(
            variables, name, [node_domain]
        )

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; required source: "
            "default DZN objective variable or the same solution's objective"
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)