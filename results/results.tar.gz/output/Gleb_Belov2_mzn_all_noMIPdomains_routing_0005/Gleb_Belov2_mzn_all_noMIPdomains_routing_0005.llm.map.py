import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def require_integer(value, field):
    if isinstance(value, bool):
        raise ValueError(field + " must be an integer, not a boolean")
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError(field + " must be a finite integer")


def decode_index(value, field):
    if not isinstance(value, dict):
        raise ValueError(field + " must use the MiniZinc set encoding")
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError(field + ".range must contain two integers")
        lower = require_integer(bounds[0], field + ".range[0]")
        upper = require_integer(bounds[1], field + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError(field + ".set must be a list")
        elements = [
            require_integer(element, field + ".set")
            for element in elements
        ]
        if len(set(elements)) != len(elements):
            raise ValueError(field + " contains duplicate indices")
        return sorted(elements)
    raise ValueError(field + " must contain exactly 'range' or 'set'")


def require_array(variables, name, expected_domains):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name + " from the default DZN solution"
        )
    value = variables[name]
    if not isinstance(value, dict):
        raise ValueError("variables." + name + " must be an encoded array")
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "variables." + name + " requires array and index_sets"
        )
    domains = value["index_sets"]
    if not isinstance(domains, list) or len(domains) != len(expected_domains):
        raise ValueError("Incorrect number of dimensions for variables." + name)
    count = 1
    for dimension, (domain, expected) in enumerate(zip(domains, expected_domains)):
        decoded = decode_index(
            domain, "variables." + name + ".index_sets[" + str(dimension) + "]"
        )
        if decoded != expected:
            raise ValueError("Incorrect index domain for variables." + name)
        count *= len(decoded)
    elements = value["array"]
    if not isinstance(elements, list) or len(elements) != count:
        raise ValueError("Incorrect element count for variables." + name)
    return {
        "array": [
            require_integer(element, "variables." + name + ".array[" + str(i) + "]")
            for i, element in enumerate(elements)
        ],
        "index_sets": domains,
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        data = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid variables object")
    variables = data["variables"]
    restored = {}

    # These singleton-domain values are fixed in the original self-contained model.
    fixed_coordinates = {
        "nXNd__1_1_X": 246,
        "nXNd__1_1_Y": 52,
        "nXNd__1_1_Z": 200,
        "nXNd__1_10_X": 309,
        "nXNd__1_10_Y": 96,
        "nXNd__1_10_Z": 80,
    }

    # The original instance explicitly declares ten nodes and three coordinates.
    # All nonfixed coordinates remain independent declarations in the new model.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                restored[name] = require_integer(variables[name], "variables." + name)
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                raise ValueError(
                    "Missing variables." + name + " from the default DZN solution"
                )

    node_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        restored[name] = require_array(
            variables, name, [node_domain, coordinate_domain]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        restored[name] = require_array(variables, name, [node_domain])

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in data and data["objective"] is not None:
        restored["obj"] = require_integer(data["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj from the default DZN solution "
            "and missing non-null objective"
        )

    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(
            {"variables": restored},
            handle,
            allow_nan=False,
            separators=(",", ":"),
        )
        handle.write("\n")


if __name__ == "__main__":
    main()