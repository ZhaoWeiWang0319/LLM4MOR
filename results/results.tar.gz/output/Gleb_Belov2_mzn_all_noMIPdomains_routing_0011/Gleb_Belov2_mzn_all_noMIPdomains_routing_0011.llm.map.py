import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the default DZN "
            "solution of the reformulated model".format(name)
        )
    return variables[name]


def map_solution(document):
    if "variables" not in document:
        raise ValueError("Missing variables from the reformulated solution")
    variables = document["variables"]
    if not isinstance(variables, dict):
        raise ValueError("variables must be a JSON object")

    # These singleton-domain values are unchanged in the self-contained
    # original model. They may be omitted by default DZN output.
    fixed_coordinates = {
        "nXNd__1_1_X": 79,
        "nXNd__1_1_Y": 41,
        "nXNd__1_1_Z": 5,
        "nXNd__1_10_X": 125,
        "nXNd__1_10_Y": 60,
        "nXNd__1_10_Z": 163,
    }

    result = {}
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in fixed_coordinates:
                if name in variables and variables[name] is not None:
                    result[name] = variables[name]
                else:
                    result[name] = fixed_coordinates[name]
            else:
                result[name] = require_variable(variables, name)

    # All original independent arrays retain their names, dimensions,
    # index domains, and meanings. Copy their encoded values unchanged.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        result[name] = require_variable(variables, name)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = variables["obj"]
    elif "objective" in document and document["objective"] is not None:
        value = document["objective"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("objective must be numeric to reconstruct obj")
        if isinstance(value, float):
            if not math.isfinite(value) or not value.is_integer():
                raise ValueError("objective must be a finite integer for obj")
        result["obj"] = int(value)
    else:
        raise ValueError(
            "Missing variables.obj and objective; obj requires its "
            "default DZN value or the unchanged optimization objective"
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        document = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    if not isinstance(document, dict):
        raise ValueError("Input must be a JSON object")
    check_finite(document, "input")
    result = map_solution(document)
    check_finite(result, "output")
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(result, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    main()