import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 245,
    "nXNd__1_1_Y": 43,
    "nXNd__1_1_Z": 122,
    "nXNd__1_10_X": 212,
    "nXNd__1_10_Y": 52,
    "nXNd__1_10_Z": 100,
}

COORDINATE_NAMES = tuple(
    f"nXNd__1_{node}_{axis}"
    for node in range(1, 11)
    for axis in ("X", "Y", "Z")
)

ARRAY_NAMES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError(f"Invalid nonfinite JSON number: {value}")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"Nonfinite number at {path}")
    if isinstance(value, list):
        for position, element in enumerate(value):
            check_finite(element, f"{path}[{position}]")
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, f"{path}.{key}")


def required_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            f"Missing variables.{name}; required from the solver's "
            "default DZN solution."
        )
    return variables[name]


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = payload["variables"]
    restored = {}

    for name in COORDINATE_NAMES:
        if name in variables and variables[name] is not None:
            restored[name] = variables[name]
        elif name in FIXED_ENDPOINTS:
            restored[name] = FIXED_ENDPOINTS[name]
        else:
            restored[name] = required_value(variables, name)

    for name in ARRAY_NAMES:
        value = required_value(variables, name)
        if not isinstance(value, dict):
            raise ValueError(f"variables.{name} must use MiniZinc array encoding.")
        if "array" not in value or "index_sets" not in value:
            raise ValueError(
                f"variables.{name} requires array and index_sets fields."
            )
        restored[name] = value

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in payload and payload["objective"] is not None:
        objective = payload["objective"]
        if isinstance(objective, bool) or not isinstance(objective, (int, float)):
            raise ValueError("objective must be a finite integer-valued number.")
        if isinstance(objective, float):
            if not math.isfinite(objective) or not objective.is_integer():
                raise ValueError("objective must be a finite integer-valued number.")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required to restore obj."
        )

    check_finite(restored, "variables")
    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(payload, "input")
    result = map_solution(payload)

    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError) as error:
        print(f"Mapping error: {error}", file=sys.stderr)
        sys.exit(1)