import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite numeric value")
    if isinstance(value, dict):
        for item in value.values():
            check_finite(item)
    elif isinstance(value, list):
        for item in value:
            check_finite(item)


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        data = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    check_finite(data)

    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing required object: variables")

    source = data["variables"]
    result = {}

    fixed = {
        "nXNd__1_1_X": 176,
        "nXNd__1_1_Y": 44,
        "nXNd__1_1_Z": 27,
        "nXNd__1_10_X": 210,
        "nXNd__1_10_Y": 83,
        "nXNd__1_10_Z": 45,
    }

    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, coordinate)
            if name in fixed:
                result[name] = fixed[name]
            elif name not in source or source[name] is None:
                raise ValueError(
                    "Missing required variable in default DZN solution: " + name
                )
            else:
                result[name] = source[name]

    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        if name not in source or source[name] is None:
            raise ValueError(
                "Missing required variable in default DZN solution: " + name
            )
        result[name] = source[name]

    check_finite(result)

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": result}, stream, allow_nan=False)


if __name__ == "__main__":
    main()