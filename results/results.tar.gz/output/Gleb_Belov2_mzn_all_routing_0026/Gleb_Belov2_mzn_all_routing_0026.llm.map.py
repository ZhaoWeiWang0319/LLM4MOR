import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the reformulated model's default DZN solution"
        )
    return variables[name]


def map_solution(data):
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")
    variables = data["variables"]
    result = {}

    # These six coordinates have singleton domains in the original,
    # self-contained model. Their values do not depend on solver output.
    fixed_coordinates = {
        "nXNd__1_1_X": 308,
        "nXNd__1_1_Y": 47,
        "nXNd__1_1_Z": 43,
        "nXNd__1_10_X": 298,
        "nXNd__1_10_Y": 25,
        "nXNd__1_10_Z": 3,
    }

    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + coordinate
            if name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                result[name] = require_variable(variables, name)

    # All original independent leg arrays and the objective variable
    # retain their names, dimensions, indices, and meanings.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
        "obj",
    ):
        result[name] = require_variable(variables, name)

    check_finite(result, "variables")
    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as handle:
        data = json.load(
            handle,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(data, "input")
    output = map_solution(data)
    with open(sys.argv[2], "w", encoding="utf-8") as handle:
        json.dump(output, handle, allow_nan=False, separators=(",", ":"))
        handle.write("\n")


if __name__ == "__main__":
    main()