import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def integer_value(value, field):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected a finite integer for " + field)


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables."
            + name
            + "; expected from the reformulated model's default DZN solution"
        )
    return variables[name]


def index_values(encoded, field):
    if not isinstance(encoded, dict):
        raise ValueError("Invalid index-set encoding for " + field)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range for " + field)
        lower = integer_value(bounds[0], field)
        upper = integer_value(bounds[1], field)
        return list(range(lower, upper + 1))
    if set(encoded) == {"set"}:
        values = encoded["set"]
        if not isinstance(values, list):
            raise ValueError("Invalid set for " + field)
        values = [integer_value(value, field) for value in values]
        if len(set(values)) != len(values):
            raise ValueError("Duplicate index in " + field)
        return sorted(values)
    raise ValueError("Invalid index-set encoding for " + field)


def copy_array(variables, name, expected_domains):
    encoded = required(variables, name)
    if not isinstance(encoded, dict):
        raise ValueError("Expected MiniZinc array encoding for variables." + name)
    if "array" not in encoded or "index_sets" not in encoded:
        raise ValueError("Missing array or index_sets in variables." + name)
    elements = encoded["array"]
    domains = encoded["index_sets"]
    if not isinstance(elements, list) or not isinstance(domains, list):
        raise ValueError("Invalid MiniZinc array encoding for variables." + name)
    if len(domains) != len(expected_domains):
        raise ValueError("Incorrect dimension count for variables." + name)
    count = 1
    for dimension, (domain, expected) in enumerate(zip(domains, expected_domains)):
        actual = index_values(domain, name + ".index_sets[" + str(dimension) + "]")
        if actual != expected:
            raise ValueError("Incorrect index domain for variables." + name)
        count *= len(actual)
    if len(elements) != count:
        raise ValueError("Incorrect element count for variables." + name)
    return {
        "array": [
            integer_value(value, name + ".array[" + str(position) + "]")
            for position, value in enumerate(elements)
        ],
        "index_sets": domains,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing required object variables")
    variables = payload["variables"]
    result = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 315,
        "nXNd__1_1_Y": 54,
        "nXNd__1_1_Z": 73,
        "nXNd__1_10_X": 335,
        "nXNd__1_10_Y": 53,
        "nXNd__1_10_Z": 8,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + axis
            if name in variables and variables[name] is not None:
                result[name] = integer_value(variables[name], "variables." + name)
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                result[name] = integer_value(
                    required(variables, name), "variables." + name
                )

    leg_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = copy_array(
            variables, name, [leg_domain, coordinate_domain]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = copy_array(variables, name, [leg_domain])

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = integer_value(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = integer_value(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; one must supply the "
            "reformulated solution's unchanged objective value"
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    mapped = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump(mapped, target, allow_nan=False, separators=(",", ":"))
        target.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)