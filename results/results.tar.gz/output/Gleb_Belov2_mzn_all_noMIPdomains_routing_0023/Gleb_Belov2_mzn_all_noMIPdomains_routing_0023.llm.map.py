import json
import math
import sys


# These data are embedded in the original self-contained model.
ORIGINAL_NODE_PIPE = (1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
ORIGINAL_FIRST_ENDPOINT = (275, 54, 8)
ORIGINAL_LAST_ENDPOINT = (255, 52, 143)
ORIGINAL_FIRST_DIRECTION = 3
ORIGINAL_LAST_DIRECTION = 4
COORDINATES = ("X", "Y", "Z")

ORIGINAL_ARRAY_VARIABLES = (
    "nXLeg1",
    "nXLeg2",
    "nLLeg",
    "nDirLeg",
    "fExistLeg",
    "fLastLeg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, index))


def required_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the default DZN solution."
            .format(name)
        )
    return variables[name]


def integer_value(value, path):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    raise ValueError("Expected an integer at " + path)


def decode_index_set(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = integer_value(bounds[0], path + ".range[0]")
        upper = integer_value(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        result = [
            integer_value(item, path + ".set")
            for item in elements
        ]
        if len(set(result)) != len(result):
            raise ValueError("Duplicate index at " + path)
        return sorted(result)
    raise ValueError("Invalid encoded index set at " + path)


def copy_array(variables, name, expected_domains):
    encoded = required_variable(variables, name)
    path = "variables." + name
    if not isinstance(encoded, dict):
        raise ValueError("Expected an encoded array at " + path)
    if "array" not in encoded or "index_sets" not in encoded:
        raise ValueError("Missing array or index_sets at " + path)
    elements = encoded["array"]
    index_sets = encoded["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + path)
    if len(index_sets) != len(expected_domains):
        raise ValueError("Wrong array dimension at " + path)

    element_count = 1
    for dimension, (index_set, expected) in enumerate(
        zip(index_sets, expected_domains)
    ):
        actual = decode_index_set(
            index_set, "{}.index_sets[{}]".format(path, dimension)
        )
        if actual != expected:
            raise ValueError("Unexpected index domain at " + path)
        element_count *= len(actual)

    if len(elements) != element_count:
        raise ValueError("Wrong element count at " + path)

    return {
        "array": [
            integer_value(value, "{}.array[{}]".format(path, index))
            for index, value in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("The input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = payload["variables"]
    node_count = len(ORIGINAL_NODE_PIPE)
    fixed = {}

    for axis, label in enumerate(COORDINATES):
        fixed["nXNd__1_1_" + label] = ORIGINAL_FIRST_ENDPOINT[axis]
        fixed["nXNd__1_{}_{}".format(node_count, label)] = (
            ORIGINAL_LAST_ENDPOINT[axis]
        )

    # The first leg is along the supplied first-nozzle direction.
    first_axis = (ORIGINAL_FIRST_DIRECTION - 1) % len(COORDINATES)
    for axis, label in enumerate(COORDINATES):
        if axis != first_axis:
            fixed["nXNd__1_2_" + label] = ORIGINAL_FIRST_ENDPOINT[axis]

    # The final possible leg is absent or follows the final-nozzle direction.
    last_axis = (ORIGINAL_LAST_DIRECTION - 1) % len(COORDINATES)
    for axis, label in enumerate(COORDINATES):
        if axis != last_axis:
            fixed["nXNd__1_{}_{}".format(node_count - 1, label)] = (
                ORIGINAL_LAST_ENDPOINT[axis]
            )

    result = {}
    for node in range(1, node_count + 1):
        for label in COORDINATES:
            name = "nXNd__1_{}_{}".format(node, label)
            if name in variables and variables[name] is not None:
                result[name] = integer_value(variables[name], "variables." + name)
            elif name in fixed:
                result[name] = fixed[name]
            else:
                result[name] = integer_value(
                    required_variable(variables, name), "variables." + name
                )

    node_domain = list(range(1, node_count + 1))
    coordinate_domain = list(range(1, len(COORDINATES) + 1))
    for name in ORIGINAL_ARRAY_VARIABLES:
        domains = (
            [node_domain, coordinate_domain]
            if name in ("nXLeg1", "nXLeg2", "nLLeg")
            else [node_domain]
        )
        result[name] = copy_array(variables, name, domains)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = integer_value(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = integer_value(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; the original obj value "
            "must come from the reformulated solution."
        )

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)