import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Non-finite number at " + path)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, "{}[{}]".format(path, position))
    elif isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)


def required(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables.{}; required from the default DZN solution."
            .format(name)
        )
    return variables[name]


def integer_value(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer at " + path)
    if isinstance(value, float) and (
        not math.isfinite(value) or not value.is_integer()
    ):
        raise ValueError("Expected a finite integer at " + path)
    return int(value)


def index_elements(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = integer_value(bounds[0], path + ".range[0]")
        upper = integer_value(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        elements = [
            integer_value(item, path + ".set") for item in elements
        ]
        if len(elements) != len(set(elements)):
            raise ValueError("Duplicate index at " + path)
        return sorted(elements)
    raise ValueError("Invalid index-set encoding at " + path)


def copy_integer_array(variables, name, expected_domains):
    value = required(variables, name)
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded array at variables." + name)
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "Missing array or index_sets at variables." + name
        )
    entries = value["array"]
    domains = value["index_sets"]
    if not isinstance(entries, list) or not isinstance(domains, list):
        raise ValueError("Invalid array encoding at variables." + name)
    if len(domains) != len(expected_domains):
        raise ValueError("Wrong number of dimensions for " + name)
    count = 1
    for dimension, (domain, expected) in enumerate(
        zip(domains, expected_domains)
    ):
        actual = index_elements(
            domain, "variables.{}.index_sets[{}]".format(name, dimension)
        )
        if actual != expected:
            raise ValueError("Incorrect index domain for " + name)
        count *= len(actual)
    if len(entries) != count:
        raise ValueError("Incorrect element count for " + name)
    return {
        "array": [
            integer_value(item, "variables.{}.array[{}]".format(name, i))
            for i, item in enumerate(entries)
        ],
        "index_sets": domains,
    }


def map_solution(data):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")
    variables = data["variables"]
    result = {}

    # These singleton domains are fixed in the original self-contained file.
    fixed_coordinates = {
        "nXNd__1_1_X": 245,
        "nXNd__1_1_Y": 108,
        "nXNd__1_1_Z": 115,
        "nXNd__1_10_X": 245,
        "nXNd__1_10_Y": 62,
        "nXNd__1_10_Z": 113,
    }

    # All coordinates retain their original independent scalar declarations.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                result[name] = integer_value(
                    variables[name], "variables." + name
                )
            elif name in fixed_coordinates:
                result[name] = fixed_coordinates[name]
            else:
                result[name] = integer_value(
                    required(variables, name), "variables." + name
                )

    # The unchanged original instance has ten leg-array rows, including
    # the final dummy row, and three coordinate columns.
    leg_domain = list(range(1, 11))
    coordinate_domain = list(range(1, 4))

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = copy_integer_array(
            variables, name, [leg_domain, coordinate_domain]
        )

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = copy_integer_array(
            variables, name, [leg_domain]
        )

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = integer_value(variables["obj"], "variables.obj")
    else:
        if "objective" not in data or data["objective"] is None:
            raise ValueError(
                "Missing variables.obj and objective; the unchanged "
                "objective value is required from the reformulated solution."
            )
        result["obj"] = integer_value(data["objective"], "objective")

    return {"variables": result}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(data, "input")
    result = map_solution(data)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    main()