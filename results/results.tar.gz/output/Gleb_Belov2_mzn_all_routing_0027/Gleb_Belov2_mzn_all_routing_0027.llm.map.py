import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        data = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(data, "input")

    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")
    variables = data["variables"]
    restored = {}

    # These values are fixed by the original self-contained instance,
    # including consequences of its first and last nozzle directions.
    fixed_coordinates = {
        "nXNd__1_1_X": 335,
        "nXNd__1_1_Y": 43,
        "nXNd__1_1_Z": 8,
        "nXNd__1_2_X": 335,
        "nXNd__1_2_Y": 43,
        "nXNd__1_9_Y": 54,
        "nXNd__1_9_Z": 93,
        "nXNd__1_10_X": 315,
        "nXNd__1_10_Y": 54,
        "nXNd__1_10_Z": 93,
    }

    # The ten node declarations are embedded in the original main file.
    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                restored[name] = variables[name]
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                raise ValueError(
                    "Missing required field variables.{} "
                    "from the default DZN solution".format(name)
                )

    # These original independent arrays are retained with unchanged
    # names, meanings, dimensions, and index domains.
    for name in (
        "nXLeg1",
        "nXLeg2",
        "nLLeg",
        "nDirLeg",
        "fExistLeg",
        "fLastLeg",
    ):
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field variables.{} "
                "from the default DZN solution".format(name)
            )
        value = variables[name]
        if (
            not isinstance(value, dict)
            or "array" not in value
            or "index_sets" not in value
        ):
            raise ValueError(
                "Expected MiniZinc array encoding in variables." + name
            )
        restored[name] = value

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = variables["obj"]
    elif "objective" in data and data["objective"] is not None:
        objective = data["objective"]
        if (
            isinstance(objective, bool)
            or not isinstance(objective, (int, float))
            or int(objective) != objective
        ):
            raise ValueError("Expected an integral objective")
        restored["obj"] = int(objective)
    else:
        raise ValueError(
            "Missing variables.obj and objective; "
            "one is required to restore the original objective variable"
        )

    check_finite(restored, "output.variables")
    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": restored}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()