import json
import math
import sys


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            check_finite(item, path + "[" + str(index) + "]")


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer at " + path)
    return int(value)


def decode_index_set(value, path):
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(value) == {"range"}:
        bounds = value["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return list(range(lower, upper + 1))
    if set(value) == {"set"}:
        elements = value["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        elements = [
            require_integer(item, path + ".set")
            for item in elements
        ]
        if len(elements) != len(set(elements)):
            raise ValueError("Duplicate index at " + path)
        return sorted(elements)
    raise ValueError("Invalid encoded index set at " + path)


def require_array(variables, name, dimensions):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required from the default DZN solution."
        )
    value = variables[name]
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded array at variables." + name)
    if "array" not in value or "index_sets" not in value:
        raise ValueError(
            "Missing array or index_sets at variables." + name
        )
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid encoded array at variables." + name)
    if len(index_sets) != dimensions:
        raise ValueError("Incorrect dimension count for variables." + name)
    size = 1
    for axis, index_set in enumerate(index_sets):
        size *= len(decode_index_set(
            index_set,
            "variables." + name + ".index_sets[" + str(axis) + "]"
        ))
    if len(elements) != size:
        raise ValueError("Incorrect element count for variables." + name)
    return {
        "array": [
            require_integer(item, "variables." + name + ".array")
            for item in elements
        ],
        "index_sets": index_sets,
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        data = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )

    check_finite(data, "input")
    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object.")
    if "variables" not in data or not isinstance(data["variables"], dict):
        raise ValueError("Missing or invalid input field: variables")

    variables = data["variables"]
    restored = {}

    fixed_coordinates = {
        "nXNd__1_1_X": 65,
        "nXNd__1_1_Y": 114,
        "nXNd__1_1_Z": 80,
        "nXNd__1_10_X": 64,
        "nXNd__1_10_Y": 41,
        "nXNd__1_10_Z": 5,
    }

    for node in range(1, 11):
        for coordinate in ("X", "Y", "Z"):
            name = "nXNd__1_" + str(node) + "_" + coordinate
            if name in variables and variables[name] is not None:
                restored[name] = require_integer(
                    variables[name], "variables." + name
                )
            elif name in fixed_coordinates:
                restored[name] = fixed_coordinates[name]
            else:
                raise ValueError(
                    "Missing variables." + name
                    + "; required from the default DZN solution."
                )

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        restored[name] = require_array(variables, name, 2)

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        restored[name] = require_array(variables, name, 1)

    if "obj" in variables and variables["obj"] is not None:
        restored["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in data and data["objective"] is not None:
        restored["obj"] = require_integer(data["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required "
            "to restore the original objective variable."
        )

    with open(sys.argv[2], "w", encoding="utf-8") as target:
        json.dump({"variables": restored}, target, allow_nan=False)
        target.write("\n")


if __name__ == "__main__":
    main()