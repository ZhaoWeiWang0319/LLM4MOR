import json
import sys


ORIGINAL_VARIABLES = (
    "Items",
    "TransP",
    "TransN",
    "Trans_pos",
    "Trans_neg",
)


def reject_constant(value):
    raise ValueError("Non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )

    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    if "variables" not in payload:
        raise ValueError("Missing required field: variables")
    variables = payload["variables"]
    if not isinstance(variables, dict):
        raise ValueError("Field variables must be a JSON object")

    restored = {}
    for name in ORIGINAL_VARIABLES:
        if name not in variables or variables[name] is None:
            raise ValueError(
                "Missing required field: variables."
                + name
                + "; expected the unchanged original decision array "
                "from the solver's default DZN solution"
            )
        restored[name] = variables[name]

    result = json.dumps(
        {"variables": restored},
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    )
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        destination.write(result)
        destination.write("\n")


if __name__ == "__main__":
    main()