import json
import sys
required = ['Items', 'TransN', 'TransP', 'Trans_neg', 'Trans_pos']
with open(sys.argv[1], encoding='utf-8') as stream:
    solution = json.load(stream)
with open(sys.argv[2], 'w', encoding='utf-8') as stream:
    json.dump({'variables': {name: solution['variables'][name] for name in required}}, stream, allow_nan=False)
