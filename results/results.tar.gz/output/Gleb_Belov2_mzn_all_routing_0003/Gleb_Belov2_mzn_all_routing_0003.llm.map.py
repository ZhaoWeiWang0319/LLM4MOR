import json
import math
import sys


def reject_constant(value):
    raise ValueError("Invalid non-finite JSON number: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Non-finite number at " + path)
    if isinstance(value, list):
        for index, element in enumerate(value):
            check_finite(element, "{}[{}]".format(path, index))
    elif isinstance(value, dict):
        for key, element in value.items():
            check_finite(element, path + "." + key)


def require_variable(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing required field variables.{} from the default DZN solution"
            .format(name)
        )
    return variables[name]


def require_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer value at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer value at " + path)
    return int(value)


def index_cardinality(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        lower = require_integer(bounds[0], path + ".range[0]")
        upper = require_integer(bounds[1], path + ".range[1]")
        return max(0, upper - lower + 1)
    if set(encoded) == {"set"}:
        elements = encoded["set"]
        if not isinstance(elements, list):
            raise ValueError("Invalid set at " + path)
        values = [
            require_integer(element, path + ".set")
            for element in elements
        ]
        if len(set(values)) != len(values):
            raise ValueError("Duplicate index-set elements at " + path)
        return len(values)
    raise ValueError("Invalid encoded index set at " + path)


def copy_integer_array(variables, name, dimensions):
    value = require_variable(variables, name)
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected encoded array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    index_sets = value["index_sets"]
    if not isinstance(elements, list) or not isinstance(index_sets, list):
        raise ValueError("Invalid array encoding at " + path)
    if len(index_sets) != dimensions:
        raise ValueError("Incorrect number of dimensions at " + path)
    expected_length = 1
    for dimension, encoded in enumerate(index_sets):
        expected_length *= index_cardinality(
            encoded, "{}.index_sets[{}]".format(path, dimension)
        )
    if len(elements) != expected_length:
        raise ValueError("Array size does not match index sets at " + path)
    return {
        "array": [
            require_integer(element, "{}.array[{}]".format(path, index))
            for index, element in enumerate(elements)
        ],
        "index_sets": index_sets,
    }


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")

    with open(sys.argv[1], "r", encoding="utf-8") as stream:
        payload = json.load(
            stream,
            parse_constant=reject_constant,
            object_pairs_hook=unique_object,
        )
    check_finite(payload, "input")
    if not isinstance(payload, dict):
        raise ValueError("Expected a JSON object")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing required object variables")

    variables = payload["variables"]
    result = {}

    fixed_endpoints = {
        "nXNd__1_1_X": 139,
        "nXNd__1_1_Y": 51,
        "nXNd__1_1_Z": 167,
        "nXNd__1_10_X": 1,
        "nXNd__1_10_Y": 88,
        "nXNd__1_10_Z": 36,
    }

    for node in range(1, 11):
        for axis in ("X", "Y", "Z"):
            name = "nXNd__1_{}_{}".format(node, axis)
            if name in variables and variables[name] is not None:
                result[name] = require_integer(
                    variables[name], "variables." + name
                )
            elif name in fixed_endpoints:
                result[name] = fixed_endpoints[name]
            else:
                result[name] = require_integer(
                    require_variable(variables, name), "variables." + name
                )

    for name in ("nXLeg1", "nXLeg2", "nLLeg"):
        result[name] = copy_integer_array(variables, name, 2)

    for name in ("nDirLeg", "fExistLeg", "fLastLeg"):
        result[name] = copy_integer_array(variables, name, 1)

    if "obj" in variables and variables["obj"] is not None:
        result["obj"] = require_integer(variables["obj"], "variables.obj")
    elif "objective" in payload and payload["objective"] is not None:
        result["obj"] = require_integer(payload["objective"], "objective")
    else:
        raise ValueError(
            "Missing variables.obj and objective; one is required "
            "to restore the original objective variable"
        )

    with open(sys.argv[2], "w", encoding="utf-8") as stream:
        json.dump({"variables": result}, stream, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()