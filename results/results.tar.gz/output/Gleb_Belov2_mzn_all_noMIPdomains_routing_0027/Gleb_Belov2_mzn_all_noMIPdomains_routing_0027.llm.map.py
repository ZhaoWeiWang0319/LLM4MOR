import json
import math
import sys


FIXED_ENDPOINTS = {
    "nXNd__1_1_X": 335,
    "nXNd__1_1_Y": 43,
    "nXNd__1_1_Z": 8,
    "nXNd__1_10_X": 315,
    "nXNd__1_10_Y": 54,
    "nXNd__1_10_Z": 93,
}

NONFIXED_COORDINATES = (
    "nXNd__1_2_X", "nXNd__1_2_Y", "nXNd__1_2_Z",
    "nXNd__1_3_X", "nXNd__1_3_Y", "nXNd__1_3_Z",
    "nXNd__1_4_X", "nXNd__1_4_Y", "nXNd__1_4_Z",
    "nXNd__1_5_X", "nXNd__1_5_Y", "nXNd__1_5_Z",
    "nXNd__1_6_X", "nXNd__1_6_Y", "nXNd__1_6_Z",
    "nXNd__1_7_X", "nXNd__1_7_Y", "nXNd__1_7_Z",
    "nXNd__1_8_X", "nXNd__1_8_Y", "nXNd__1_8_Z",
    "nXNd__1_9_X", "nXNd__1_9_Y", "nXNd__1_9_Z",
)

ORIGINAL_ARRAYS = {
    "nXLeg1": 2,
    "nXLeg2": 2,
    "nLLeg": 2,
    "nDirLeg": 1,
    "fExistLeg": 1,
    "fLastLeg": 1,
}


def reject_constant(value):
    raise ValueError("Nonfinite JSON numeric constant: " + value)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def check_finite(value, path):
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Nonfinite number at " + path)
    if isinstance(value, dict):
        for key, item in value.items():
            check_finite(item, path + "." + key)
    elif isinstance(value, list):
        for position, item in enumerate(value):
            check_finite(item, path + "[" + str(position) + "]")


def require_value(variables, name):
    if name not in variables or variables[name] is None:
        raise ValueError(
            "Missing variables." + name
            + "; required source is the reformulated model's default DZN solution."
        )
    return variables[name]


def check_integer(value, path):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Expected an integer value at " + path)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise ValueError("Expected a finite integer value at " + path)


def index_cardinality(encoded, path):
    if not isinstance(encoded, dict):
        raise ValueError("Expected an encoded index set at " + path)
    if set(encoded) == {"range"}:
        bounds = encoded["range"]
        if not isinstance(bounds, list) or len(bounds) != 2:
            raise ValueError("Invalid range at " + path)
        for bound in bounds:
            if type(bound) is not int:
                raise ValueError("Index bounds must be integers at " + path)
        return max(0, bounds[1] - bounds[0] + 1)
    if set(encoded) == {"set"}:
        members = encoded["set"]
        if not isinstance(members, list):
            raise ValueError("Invalid set at " + path)
        if any(type(member) is not int for member in members):
            raise ValueError("Index members must be integers at " + path)
        if members != sorted(set(members)):
            raise ValueError("Index members must be distinct and ordered at " + path)
        return len(members)
    raise ValueError("Invalid index-set encoding at " + path)


def check_array(value, dimensions, name):
    path = "variables." + name
    if not isinstance(value, dict):
        raise ValueError("Expected an encoded array at " + path)
    if "array" not in value or "index_sets" not in value:
        raise ValueError("Missing array or index_sets at " + path)
    elements = value["array"]
    indices = value["index_sets"]
    if not isinstance(elements, list):
        raise ValueError("Expected a flattened array at " + path + ".array")
    if not isinstance(indices, list) or len(indices) != dimensions:
        raise ValueError("Incorrect number of index sets at " + path)
    expected_size = 1
    for position, encoded in enumerate(indices):
        expected_size *= index_cardinality(
            encoded, path + ".index_sets[" + str(position) + "]"
        )
    if len(elements) != expected_size:
        raise ValueError("Array size does not match index sets at " + path)
    for position, element in enumerate(elements):
        check_integer(element, path + ".array[" + str(position) + "]")


def map_solution(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object.")
    if "variables" not in payload or not isinstance(payload["variables"], dict):
        raise ValueError("Missing or invalid variables object.")

    variables = payload["variables"]
    restored = {}

    for name, fixed_value in FIXED_ENDPOINTS.items():
        if name in variables and variables[name] is not None:
            check_integer(variables[name], "variables." + name)
            restored[name] = variables[name]
        else:
            restored[name] = fixed_value

    for name in NONFIXED_COORDINATES:
        value = require_value(variables, name)
        check_integer(value, "variables." + name)
        restored[name] = value

    for name, dimensions in ORIGINAL_ARRAYS.items():
        value = require_value(variables, name)
        check_array(value, dimensions, name)
        restored[name] = value

    objective_variable = require_value(variables, "obj")
    check_integer(objective_variable, "variables.obj")
    restored["obj"] = objective_variable

    return {"variables": restored}


def main():
    if len(sys.argv) != 3:
        raise ValueError("Usage: python3 map.py input.json output.json")
    with open(sys.argv[1], "r", encoding="utf-8") as source:
        payload = json.load(
            source,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    check_finite(payload, "input")
    result = map_solution(payload)
    with open(sys.argv[2], "w", encoding="utf-8") as destination:
        json.dump(result, destination, allow_nan=False, separators=(",", ":"))
        destination.write("\n")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError) as error:
        print("Mapping error: " + str(error), file=sys.stderr)
        sys.exit(1)